gdjs.New_32sceneCode = {};
gdjs.New_32sceneCode.GDWhiteSquareObjects5_1final = [];

gdjs.New_32sceneCode.forEachIndex2 = 0;

gdjs.New_32sceneCode.forEachIndex3 = 0;

gdjs.New_32sceneCode.forEachObjects2 = [];

gdjs.New_32sceneCode.forEachObjects3 = [];

gdjs.New_32sceneCode.forEachTemporary2 = null;

gdjs.New_32sceneCode.forEachTemporary3 = null;

gdjs.New_32sceneCode.forEachTotalCount2 = 0;

gdjs.New_32sceneCode.forEachTotalCount3 = 0;

gdjs.New_32sceneCode.stopDoWhile4 = false;

gdjs.New_32sceneCode.stopDoWhile5 = false;

gdjs.New_32sceneCode.GDWhiteSquareObjects1= [];
gdjs.New_32sceneCode.GDWhiteSquareObjects2= [];
gdjs.New_32sceneCode.GDWhiteSquareObjects3= [];
gdjs.New_32sceneCode.GDWhiteSquareObjects4= [];
gdjs.New_32sceneCode.GDWhiteSquareObjects5= [];
gdjs.New_32sceneCode.GDWhiteSquareObjects6= [];
gdjs.New_32sceneCode.GDShowHideNumbersButtonObjects1= [];
gdjs.New_32sceneCode.GDShowHideNumbersButtonObjects2= [];
gdjs.New_32sceneCode.GDShowHideNumbersButtonObjects3= [];
gdjs.New_32sceneCode.GDShowHideNumbersButtonObjects4= [];
gdjs.New_32sceneCode.GDShowHideNumbersButtonObjects5= [];
gdjs.New_32sceneCode.GDShowHideNumbersButtonObjects6= [];
gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects1= [];
gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects2= [];
gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects3= [];
gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects4= [];
gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects5= [];
gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects6= [];
gdjs.New_32sceneCode.GDGreysRemovedButtonObjects1= [];
gdjs.New_32sceneCode.GDGreysRemovedButtonObjects2= [];
gdjs.New_32sceneCode.GDGreysRemovedButtonObjects3= [];
gdjs.New_32sceneCode.GDGreysRemovedButtonObjects4= [];
gdjs.New_32sceneCode.GDGreysRemovedButtonObjects5= [];
gdjs.New_32sceneCode.GDGreysRemovedButtonObjects6= [];
gdjs.New_32sceneCode.GDDarksRemovedButtonObjects1= [];
gdjs.New_32sceneCode.GDDarksRemovedButtonObjects2= [];
gdjs.New_32sceneCode.GDDarksRemovedButtonObjects3= [];
gdjs.New_32sceneCode.GDDarksRemovedButtonObjects4= [];
gdjs.New_32sceneCode.GDDarksRemovedButtonObjects5= [];
gdjs.New_32sceneCode.GDDarksRemovedButtonObjects6= [];
gdjs.New_32sceneCode.GDRandomButtonObjects1= [];
gdjs.New_32sceneCode.GDRandomButtonObjects2= [];
gdjs.New_32sceneCode.GDRandomButtonObjects3= [];
gdjs.New_32sceneCode.GDRandomButtonObjects4= [];
gdjs.New_32sceneCode.GDRandomButtonObjects5= [];
gdjs.New_32sceneCode.GDRandomButtonObjects6= [];
gdjs.New_32sceneCode.GDLoopCounterTextObjects1= [];
gdjs.New_32sceneCode.GDLoopCounterTextObjects2= [];
gdjs.New_32sceneCode.GDLoopCounterTextObjects3= [];
gdjs.New_32sceneCode.GDLoopCounterTextObjects4= [];
gdjs.New_32sceneCode.GDLoopCounterTextObjects5= [];
gdjs.New_32sceneCode.GDLoopCounterTextObjects6= [];
gdjs.New_32sceneCode.GDShowHideNumbersTextObjects1= [];
gdjs.New_32sceneCode.GDShowHideNumbersTextObjects2= [];
gdjs.New_32sceneCode.GDShowHideNumbersTextObjects3= [];
gdjs.New_32sceneCode.GDShowHideNumbersTextObjects4= [];
gdjs.New_32sceneCode.GDShowHideNumbersTextObjects5= [];
gdjs.New_32sceneCode.GDShowHideNumbersTextObjects6= [];
gdjs.New_32sceneCode.GDDarksAndGreysRemovedTextObjects1= [];
gdjs.New_32sceneCode.GDDarksAndGreysRemovedTextObjects2= [];
gdjs.New_32sceneCode.GDDarksAndGreysRemovedTextObjects3= [];
gdjs.New_32sceneCode.GDDarksAndGreysRemovedTextObjects4= [];
gdjs.New_32sceneCode.GDDarksAndGreysRemovedTextObjects5= [];
gdjs.New_32sceneCode.GDDarksAndGreysRemovedTextObjects6= [];
gdjs.New_32sceneCode.GDGreysRemovedTextObjects1= [];
gdjs.New_32sceneCode.GDGreysRemovedTextObjects2= [];
gdjs.New_32sceneCode.GDGreysRemovedTextObjects3= [];
gdjs.New_32sceneCode.GDGreysRemovedTextObjects4= [];
gdjs.New_32sceneCode.GDGreysRemovedTextObjects5= [];
gdjs.New_32sceneCode.GDGreysRemovedTextObjects6= [];
gdjs.New_32sceneCode.GDDarksRemovedTextObjects1= [];
gdjs.New_32sceneCode.GDDarksRemovedTextObjects2= [];
gdjs.New_32sceneCode.GDDarksRemovedTextObjects3= [];
gdjs.New_32sceneCode.GDDarksRemovedTextObjects4= [];
gdjs.New_32sceneCode.GDDarksRemovedTextObjects5= [];
gdjs.New_32sceneCode.GDDarksRemovedTextObjects6= [];
gdjs.New_32sceneCode.GDRandomColorsTextObjects1= [];
gdjs.New_32sceneCode.GDRandomColorsTextObjects2= [];
gdjs.New_32sceneCode.GDRandomColorsTextObjects3= [];
gdjs.New_32sceneCode.GDRandomColorsTextObjects4= [];
gdjs.New_32sceneCode.GDRandomColorsTextObjects5= [];
gdjs.New_32sceneCode.GDRandomColorsTextObjects6= [];
gdjs.New_32sceneCode.GDExplanationTextObjects1= [];
gdjs.New_32sceneCode.GDExplanationTextObjects2= [];
gdjs.New_32sceneCode.GDExplanationTextObjects3= [];
gdjs.New_32sceneCode.GDExplanationTextObjects4= [];
gdjs.New_32sceneCode.GDExplanationTextObjects5= [];
gdjs.New_32sceneCode.GDExplanationTextObjects6= [];
gdjs.New_32sceneCode.GDExplanationBoxObjects1= [];
gdjs.New_32sceneCode.GDExplanationBoxObjects2= [];
gdjs.New_32sceneCode.GDExplanationBoxObjects3= [];
gdjs.New_32sceneCode.GDExplanationBoxObjects4= [];
gdjs.New_32sceneCode.GDExplanationBoxObjects5= [];
gdjs.New_32sceneCode.GDExplanationBoxObjects6= [];
gdjs.New_32sceneCode.GDQuestionMarkObjects1= [];
gdjs.New_32sceneCode.GDQuestionMarkObjects2= [];
gdjs.New_32sceneCode.GDQuestionMarkObjects3= [];
gdjs.New_32sceneCode.GDQuestionMarkObjects4= [];
gdjs.New_32sceneCode.GDQuestionMarkObjects5= [];
gdjs.New_32sceneCode.GDQuestionMarkObjects6= [];

gdjs.New_32sceneCode.conditionTrue_0 = {val:false};
gdjs.New_32sceneCode.condition0IsTrue_0 = {val:false};
gdjs.New_32sceneCode.condition1IsTrue_0 = {val:false};
gdjs.New_32sceneCode.condition2IsTrue_0 = {val:false};
gdjs.New_32sceneCode.condition3IsTrue_0 = {val:false};
gdjs.New_32sceneCode.conditionTrue_1 = {val:false};
gdjs.New_32sceneCode.condition0IsTrue_1 = {val:false};
gdjs.New_32sceneCode.condition1IsTrue_1 = {val:false};
gdjs.New_32sceneCode.condition2IsTrue_1 = {val:false};
gdjs.New_32sceneCode.condition3IsTrue_1 = {val:false};
gdjs.New_32sceneCode.conditionTrue_2 = {val:false};
gdjs.New_32sceneCode.condition0IsTrue_2 = {val:false};
gdjs.New_32sceneCode.condition1IsTrue_2 = {val:false};
gdjs.New_32sceneCode.condition2IsTrue_2 = {val:false};
gdjs.New_32sceneCode.condition3IsTrue_2 = {val:false};


gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDWhiteSquareObjects1Objects = Hashtable.newFrom({"WhiteSquare": gdjs.New_32sceneCode.GDWhiteSquareObjects1});gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDRandomButtonObjects1Objects = Hashtable.newFrom({"RandomButton": gdjs.New_32sceneCode.GDRandomButtonObjects1});gdjs.New_32sceneCode.eventsList0 = function(runtimeScene) {

};gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDLoopCounterTextObjects2Objects = Hashtable.newFrom({"LoopCounterText": gdjs.New_32sceneCode.GDLoopCounterTextObjects2});gdjs.New_32sceneCode.eventsList1 = function(runtimeScene) {

};gdjs.New_32sceneCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("LoopCounterText"), gdjs.New_32sceneCode.GDLoopCounterTextObjects2);

for(gdjs.New_32sceneCode.forEachIndex3 = 0;gdjs.New_32sceneCode.forEachIndex3 < gdjs.New_32sceneCode.GDLoopCounterTextObjects2.length;++gdjs.New_32sceneCode.forEachIndex3) {
gdjs.New_32sceneCode.GDLoopCounterTextObjects3.length = 0;


gdjs.New_32sceneCode.forEachTemporary3 = gdjs.New_32sceneCode.GDLoopCounterTextObjects2[gdjs.New_32sceneCode.forEachIndex3];
gdjs.New_32sceneCode.GDLoopCounterTextObjects3.push(gdjs.New_32sceneCode.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDLoopCounterTextObjects3[i].deleteFromScene(runtimeScene);
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("WhiteSquare"), gdjs.New_32sceneCode.GDWhiteSquareObjects1);

for(gdjs.New_32sceneCode.forEachIndex2 = 0;gdjs.New_32sceneCode.forEachIndex2 < gdjs.New_32sceneCode.GDWhiteSquareObjects1.length;++gdjs.New_32sceneCode.forEachIndex2) {
gdjs.New_32sceneCode.GDLoopCounterTextObjects2.length = 0;

gdjs.New_32sceneCode.GDWhiteSquareObjects2.length = 0;


gdjs.New_32sceneCode.forEachTemporary2 = gdjs.New_32sceneCode.GDWhiteSquareObjects1[gdjs.New_32sceneCode.forEachIndex2];
gdjs.New_32sceneCode.GDWhiteSquareObjects2.push(gdjs.New_32sceneCode.forEachTemporary2);
if (true) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects2[i].setColor(gdjs.evtTools.common.toString(gdjs.randomInRange(0, 255)) + ";" + gdjs.evtTools.common.toString(gdjs.randomInRange(0, 255)) + ";" + gdjs.evtTools.common.toString(gdjs.randomInRange(0, 255)));
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects2[i].getVariables().get("LoopCounter")).setNumber(1);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDLoopCounterTextObjects2Objects, (( gdjs.New_32sceneCode.GDWhiteSquareObjects2.length === 0 ) ? 0 :gdjs.New_32sceneCode.GDWhiteSquareObjects2[0].getPointX("Center")) - 10, (( gdjs.New_32sceneCode.GDWhiteSquareObjects2.length === 0 ) ? 0 :gdjs.New_32sceneCode.GDWhiteSquareObjects2[0].getPointY("")) + 10, "");
}{for(var i = 0, len = gdjs.New_32sceneCode.GDLoopCounterTextObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDLoopCounterTextObjects2[i].setString(gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects2[0].getVariables()).get("LoopCounter")))));
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDLoopCounterTextObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDLoopCounterTextObjects2[i].setZOrder(100);
}
}}
}

}


};gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDDarksRemovedButtonObjects1Objects = Hashtable.newFrom({"DarksRemovedButton": gdjs.New_32sceneCode.GDDarksRemovedButtonObjects1});gdjs.New_32sceneCode.eventsList3 = function(runtimeScene) {

};gdjs.New_32sceneCode.eventsList4 = function(runtimeScene) {

};gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDLoopCounterTextObjects3Objects = Hashtable.newFrom({"LoopCounterText": gdjs.New_32sceneCode.GDLoopCounterTextObjects3});gdjs.New_32sceneCode.eventsList5 = function(runtimeScene) {

{


gdjs.New_32sceneCode.stopDoWhile4 = false;
do {gdjs.copyArray(gdjs.New_32sceneCode.GDWhiteSquareObjects2, gdjs.New_32sceneCode.GDWhiteSquareObjects4);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
{gdjs.New_32sceneCode.conditionTrue_1 = gdjs.New_32sceneCode.condition0IsTrue_0;
gdjs.New_32sceneCode.conditionTrue_1.val = ((gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects4[0].getVariables()).get("RedValue"))) + (gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects4[0].getVariables()).get("GreenValue"))) + (gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects4[0].getVariables()).get("BlueValue"))) < 255);
}
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
if (true) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects4[i].getVariables().get("RedValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects4[i].getVariables().get("GreenValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects4[i].getVariables().get("BlueValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects4[i].getVariables().get("LoopCounter")).add(1);
}
}
{ //Subevents: 
gdjs.New_32sceneCode.eventsList4(runtimeScene);} //Subevents end.
}
} else gdjs.New_32sceneCode.stopDoWhile4 = true; 
} while ( !gdjs.New_32sceneCode.stopDoWhile4 );

}


{



}


{


{
gdjs.copyArray(gdjs.New_32sceneCode.GDWhiteSquareObjects2, gdjs.New_32sceneCode.GDWhiteSquareObjects3);

gdjs.New_32sceneCode.GDLoopCounterTextObjects3.length = 0;

{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects3[i].setColor(gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.New_32sceneCode.GDWhiteSquareObjects3[i].getVariables().get("RedValue")))) + ";" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.New_32sceneCode.GDWhiteSquareObjects3[i].getVariables().get("GreenValue")))) + ";" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.New_32sceneCode.GDWhiteSquareObjects3[i].getVariables().get("BlueValue")))));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDLoopCounterTextObjects3Objects, (( gdjs.New_32sceneCode.GDWhiteSquareObjects3.length === 0 ) ? 0 :gdjs.New_32sceneCode.GDWhiteSquareObjects3[0].getPointX("Center")) - 10, (( gdjs.New_32sceneCode.GDWhiteSquareObjects3.length === 0 ) ? 0 :gdjs.New_32sceneCode.GDWhiteSquareObjects3[0].getPointY("")) + 10, "");
}{for(var i = 0, len = gdjs.New_32sceneCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDLoopCounterTextObjects3[i].setString(gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects3[0].getVariables()).get("LoopCounter")))));
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDLoopCounterTextObjects3[i].setZOrder(100);
}
}}

}


};gdjs.New_32sceneCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("LoopCounterText"), gdjs.New_32sceneCode.GDLoopCounterTextObjects2);

for(gdjs.New_32sceneCode.forEachIndex3 = 0;gdjs.New_32sceneCode.forEachIndex3 < gdjs.New_32sceneCode.GDLoopCounterTextObjects2.length;++gdjs.New_32sceneCode.forEachIndex3) {
gdjs.New_32sceneCode.GDLoopCounterTextObjects3.length = 0;


gdjs.New_32sceneCode.forEachTemporary3 = gdjs.New_32sceneCode.GDLoopCounterTextObjects2[gdjs.New_32sceneCode.forEachIndex3];
gdjs.New_32sceneCode.GDLoopCounterTextObjects3.push(gdjs.New_32sceneCode.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDLoopCounterTextObjects3[i].deleteFromScene(runtimeScene);
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("WhiteSquare"), gdjs.New_32sceneCode.GDWhiteSquareObjects1);

for(gdjs.New_32sceneCode.forEachIndex2 = 0;gdjs.New_32sceneCode.forEachIndex2 < gdjs.New_32sceneCode.GDWhiteSquareObjects1.length;++gdjs.New_32sceneCode.forEachIndex2) {
gdjs.New_32sceneCode.GDWhiteSquareObjects2.length = 0;


gdjs.New_32sceneCode.forEachTemporary2 = gdjs.New_32sceneCode.GDWhiteSquareObjects1[gdjs.New_32sceneCode.forEachIndex2];
gdjs.New_32sceneCode.GDWhiteSquareObjects2.push(gdjs.New_32sceneCode.forEachTemporary2);
if (true) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects2[i].getVariables().get("GreenValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects2[i].getVariables().get("BlueValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects2[i].getVariables().get("RedValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects2[i].getVariables().get("LoopCounter")).setNumber(0);
}
}
{ //Subevents: 
gdjs.New_32sceneCode.eventsList5(runtimeScene);} //Subevents end.
}
}

}


};gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDGreysRemovedButtonObjects1Objects = Hashtable.newFrom({"GreysRemovedButton": gdjs.New_32sceneCode.GDGreysRemovedButtonObjects1});gdjs.New_32sceneCode.eventsList7 = function(runtimeScene) {

};gdjs.New_32sceneCode.eventsList8 = function(runtimeScene) {

};gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDLoopCounterTextObjects3Objects = Hashtable.newFrom({"LoopCounterText": gdjs.New_32sceneCode.GDLoopCounterTextObjects3});gdjs.New_32sceneCode.eventsList9 = function(runtimeScene) {

{


gdjs.New_32sceneCode.stopDoWhile4 = false;
do {gdjs.copyArray(gdjs.New_32sceneCode.GDWhiteSquareObjects2, gdjs.New_32sceneCode.GDWhiteSquareObjects4);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
{gdjs.New_32sceneCode.conditionTrue_1 = gdjs.New_32sceneCode.condition0IsTrue_0;
gdjs.New_32sceneCode.conditionTrue_1.val = (Math.max(Math.max((gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects4[0].getVariables()).get("RedValue"))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects4[0].getVariables()).get("BlueValue")))), Math.max((gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects4[0].getVariables()).get("GreenValue"))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects4[0].getVariables()).get("BlueValue"))))) - Math.min(Math.min((gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects4[0].getVariables()).get("RedValue"))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects4[0].getVariables()).get("BlueValue")))), Math.min((gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects4[0].getVariables()).get("GreenValue"))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects4[0].getVariables()).get("BlueValue"))))) < 128);
}
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
if (true) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects4[i].getVariables().get("RedValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects4[i].getVariables().get("GreenValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects4[i].getVariables().get("BlueValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects4[i].getVariables().get("LoopCounter")).add(1);
}
}
{ //Subevents: 
gdjs.New_32sceneCode.eventsList8(runtimeScene);} //Subevents end.
}
} else gdjs.New_32sceneCode.stopDoWhile4 = true; 
} while ( !gdjs.New_32sceneCode.stopDoWhile4 );

}


{



}


{


{
gdjs.copyArray(gdjs.New_32sceneCode.GDWhiteSquareObjects2, gdjs.New_32sceneCode.GDWhiteSquareObjects3);

gdjs.New_32sceneCode.GDLoopCounterTextObjects3.length = 0;

{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects3[i].setColor(gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.New_32sceneCode.GDWhiteSquareObjects3[i].getVariables().get("RedValue")))) + ";" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.New_32sceneCode.GDWhiteSquareObjects3[i].getVariables().get("GreenValue")))) + ";" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.New_32sceneCode.GDWhiteSquareObjects3[i].getVariables().get("BlueValue")))));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDLoopCounterTextObjects3Objects, (( gdjs.New_32sceneCode.GDWhiteSquareObjects3.length === 0 ) ? 0 :gdjs.New_32sceneCode.GDWhiteSquareObjects3[0].getPointX("Center")) - 10, (( gdjs.New_32sceneCode.GDWhiteSquareObjects3.length === 0 ) ? 0 :gdjs.New_32sceneCode.GDWhiteSquareObjects3[0].getPointY("")) + 10, "");
}{for(var i = 0, len = gdjs.New_32sceneCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDLoopCounterTextObjects3[i].setString(gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects3[0].getVariables()).get("LoopCounter")))));
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDLoopCounterTextObjects3[i].setZOrder(100);
}
}}

}


};gdjs.New_32sceneCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("LoopCounterText"), gdjs.New_32sceneCode.GDLoopCounterTextObjects2);

for(gdjs.New_32sceneCode.forEachIndex3 = 0;gdjs.New_32sceneCode.forEachIndex3 < gdjs.New_32sceneCode.GDLoopCounterTextObjects2.length;++gdjs.New_32sceneCode.forEachIndex3) {
gdjs.New_32sceneCode.GDLoopCounterTextObjects3.length = 0;


gdjs.New_32sceneCode.forEachTemporary3 = gdjs.New_32sceneCode.GDLoopCounterTextObjects2[gdjs.New_32sceneCode.forEachIndex3];
gdjs.New_32sceneCode.GDLoopCounterTextObjects3.push(gdjs.New_32sceneCode.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDLoopCounterTextObjects3[i].deleteFromScene(runtimeScene);
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("WhiteSquare"), gdjs.New_32sceneCode.GDWhiteSquareObjects1);

for(gdjs.New_32sceneCode.forEachIndex2 = 0;gdjs.New_32sceneCode.forEachIndex2 < gdjs.New_32sceneCode.GDWhiteSquareObjects1.length;++gdjs.New_32sceneCode.forEachIndex2) {
gdjs.New_32sceneCode.GDWhiteSquareObjects2.length = 0;


gdjs.New_32sceneCode.forEachTemporary2 = gdjs.New_32sceneCode.GDWhiteSquareObjects1[gdjs.New_32sceneCode.forEachIndex2];
gdjs.New_32sceneCode.GDWhiteSquareObjects2.push(gdjs.New_32sceneCode.forEachTemporary2);
if (true) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects2[i].getVariables().get("GreenValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects2[i].getVariables().get("BlueValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects2[i].getVariables().get("RedValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects2[i].getVariables().get("LoopCounter")).setNumber(0);
}
}
{ //Subevents: 
gdjs.New_32sceneCode.eventsList9(runtimeScene);} //Subevents end.
}
}

}


};gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDDarksAndGreysRemovedButtonObjects1Objects = Hashtable.newFrom({"DarksAndGreysRemovedButton": gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects1});gdjs.New_32sceneCode.eventsList11 = function(runtimeScene) {

};gdjs.New_32sceneCode.eventsList12 = function(runtimeScene) {

};gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDLoopCounterTextObjects4Objects = Hashtable.newFrom({"LoopCounterText": gdjs.New_32sceneCode.GDLoopCounterTextObjects4});gdjs.New_32sceneCode.eventsList13 = function(runtimeScene) {

{


gdjs.New_32sceneCode.stopDoWhile5 = false;
do {gdjs.copyArray(gdjs.New_32sceneCode.GDWhiteSquareObjects3, gdjs.New_32sceneCode.GDWhiteSquareObjects5);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
{gdjs.New_32sceneCode.conditionTrue_1 = gdjs.New_32sceneCode.condition0IsTrue_0;
gdjs.New_32sceneCode.GDWhiteSquareObjects5_1final.length = 0;gdjs.New_32sceneCode.condition0IsTrue_1.val = false;
gdjs.New_32sceneCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.New_32sceneCode.GDWhiteSquareObjects3, gdjs.New_32sceneCode.GDWhiteSquareObjects6);

{gdjs.New_32sceneCode.conditionTrue_2 = gdjs.New_32sceneCode.condition0IsTrue_1;
gdjs.New_32sceneCode.conditionTrue_2.val = ((gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects6[0].getVariables()).get("RedValue"))) + (gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects6[0].getVariables()).get("GreenValue"))) + (gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects6[0].getVariables()).get("BlueValue"))) < 255);
}
if( gdjs.New_32sceneCode.condition0IsTrue_1.val ) {
    gdjs.New_32sceneCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.New_32sceneCode.GDWhiteSquareObjects6.length;j<jLen;++j) {
        if ( gdjs.New_32sceneCode.GDWhiteSquareObjects5_1final.indexOf(gdjs.New_32sceneCode.GDWhiteSquareObjects6[j]) === -1 )
            gdjs.New_32sceneCode.GDWhiteSquareObjects5_1final.push(gdjs.New_32sceneCode.GDWhiteSquareObjects6[j]);
    }
}
}
{
gdjs.copyArray(gdjs.New_32sceneCode.GDWhiteSquareObjects3, gdjs.New_32sceneCode.GDWhiteSquareObjects6);

{gdjs.New_32sceneCode.conditionTrue_2 = gdjs.New_32sceneCode.condition1IsTrue_1;
gdjs.New_32sceneCode.conditionTrue_2.val = (Math.max(Math.max((gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects6[0].getVariables()).get("RedValue"))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects6[0].getVariables()).get("BlueValue")))), Math.max((gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects6[0].getVariables()).get("GreenValue"))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects6[0].getVariables()).get("BlueValue"))))) - Math.min(Math.min((gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects6[0].getVariables()).get("RedValue"))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects6[0].getVariables()).get("BlueValue")))), Math.min((gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects6[0].getVariables()).get("GreenValue"))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects6[0].getVariables()).get("BlueValue"))))) < 128);
}
if( gdjs.New_32sceneCode.condition1IsTrue_1.val ) {
    gdjs.New_32sceneCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.New_32sceneCode.GDWhiteSquareObjects6.length;j<jLen;++j) {
        if ( gdjs.New_32sceneCode.GDWhiteSquareObjects5_1final.indexOf(gdjs.New_32sceneCode.GDWhiteSquareObjects6[j]) === -1 )
            gdjs.New_32sceneCode.GDWhiteSquareObjects5_1final.push(gdjs.New_32sceneCode.GDWhiteSquareObjects6[j]);
    }
}
}
{
gdjs.copyArray(gdjs.New_32sceneCode.GDWhiteSquareObjects5_1final, gdjs.New_32sceneCode.GDWhiteSquareObjects5);
}
}
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
if (true) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects5.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects5[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects5[i].getVariables().get("RedValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects5.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects5[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects5[i].getVariables().get("GreenValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects5.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects5[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects5[i].getVariables().get("BlueValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects5.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects5[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects5[i].getVariables().get("LoopCounter")).add(1);
}
}
{ //Subevents: 
gdjs.New_32sceneCode.eventsList12(runtimeScene);} //Subevents end.
}
} else gdjs.New_32sceneCode.stopDoWhile5 = true; 
} while ( !gdjs.New_32sceneCode.stopDoWhile5 );

}


{



}


{


{
gdjs.copyArray(gdjs.New_32sceneCode.GDWhiteSquareObjects3, gdjs.New_32sceneCode.GDWhiteSquareObjects4);

gdjs.New_32sceneCode.GDLoopCounterTextObjects4.length = 0;

{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects4[i].setColor(gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.New_32sceneCode.GDWhiteSquareObjects4[i].getVariables().get("RedValue")))) + ";" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.New_32sceneCode.GDWhiteSquareObjects4[i].getVariables().get("GreenValue")))) + ";" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.New_32sceneCode.GDWhiteSquareObjects4[i].getVariables().get("BlueValue")))));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDLoopCounterTextObjects4Objects, (( gdjs.New_32sceneCode.GDWhiteSquareObjects4.length === 0 ) ? 0 :gdjs.New_32sceneCode.GDWhiteSquareObjects4[0].getPointX("Center")) - 10, (( gdjs.New_32sceneCode.GDWhiteSquareObjects4.length === 0 ) ? 0 :gdjs.New_32sceneCode.GDWhiteSquareObjects4[0].getPointY("")) + 10, "");
}{for(var i = 0, len = gdjs.New_32sceneCode.GDLoopCounterTextObjects4.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDLoopCounterTextObjects4[i].setString(gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.New_32sceneCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.New_32sceneCode.GDWhiteSquareObjects4[0].getVariables()).get("LoopCounter")))));
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDLoopCounterTextObjects4.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDLoopCounterTextObjects4[i].setZOrder(100);
}
}}

}


};gdjs.New_32sceneCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("LoopCounterText"), gdjs.New_32sceneCode.GDLoopCounterTextObjects2);

for(gdjs.New_32sceneCode.forEachIndex3 = 0;gdjs.New_32sceneCode.forEachIndex3 < gdjs.New_32sceneCode.GDLoopCounterTextObjects2.length;++gdjs.New_32sceneCode.forEachIndex3) {
gdjs.New_32sceneCode.GDLoopCounterTextObjects3.length = 0;


gdjs.New_32sceneCode.forEachTemporary3 = gdjs.New_32sceneCode.GDLoopCounterTextObjects2[gdjs.New_32sceneCode.forEachIndex3];
gdjs.New_32sceneCode.GDLoopCounterTextObjects3.push(gdjs.New_32sceneCode.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDLoopCounterTextObjects3[i].deleteFromScene(runtimeScene);
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("WhiteSquare"), gdjs.New_32sceneCode.GDWhiteSquareObjects2);

for(gdjs.New_32sceneCode.forEachIndex3 = 0;gdjs.New_32sceneCode.forEachIndex3 < gdjs.New_32sceneCode.GDWhiteSquareObjects2.length;++gdjs.New_32sceneCode.forEachIndex3) {
gdjs.New_32sceneCode.GDWhiteSquareObjects3.length = 0;


gdjs.New_32sceneCode.forEachTemporary3 = gdjs.New_32sceneCode.GDWhiteSquareObjects2[gdjs.New_32sceneCode.forEachIndex3];
gdjs.New_32sceneCode.GDWhiteSquareObjects3.push(gdjs.New_32sceneCode.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects3[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects3[i].getVariables().get("GreenValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects3[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects3[i].getVariables().get("BlueValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects3[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects3[i].getVariables().get("RedValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDWhiteSquareObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDWhiteSquareObjects3[i].returnVariable(gdjs.New_32sceneCode.GDWhiteSquareObjects3[i].getVariables().get("LoopCounter")).setNumber(0);
}
}
{ //Subevents: 
gdjs.New_32sceneCode.eventsList13(runtimeScene);} //Subevents end.
}
}

}


{


{
}

}


};gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDShowHideNumbersButtonObjects1Objects = Hashtable.newFrom({"ShowHideNumbersButton": gdjs.New_32sceneCode.GDShowHideNumbersButtonObjects1});gdjs.New_32sceneCode.eventsList15 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("LoopCounterText"), gdjs.New_32sceneCode.GDLoopCounterTextObjects2);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDLoopCounterTextObjects2.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDLoopCounterTextObjects2[i].isVisible() ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDLoopCounterTextObjects2[k] = gdjs.New_32sceneCode.GDLoopCounterTextObjects2[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDLoopCounterTextObjects2.length = k;}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("ShowNumbers").setNumber(0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("LoopCounterText"), gdjs.New_32sceneCode.GDLoopCounterTextObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDLoopCounterTextObjects1.length;i<l;++i) {
    if ( !(gdjs.New_32sceneCode.GDLoopCounterTextObjects1[i].isVisible()) ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDLoopCounterTextObjects1[k] = gdjs.New_32sceneCode.GDLoopCounterTextObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDLoopCounterTextObjects1.length = k;}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("ShowNumbers").setNumber(1);
}}

}


};gdjs.New_32sceneCode.eventsList16 = function(runtimeScene) {

{


gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
gdjs.New_32sceneCode.condition1IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.New_32sceneCode.condition0IsTrue_0.val ) {
{
{gdjs.New_32sceneCode.conditionTrue_1 = gdjs.New_32sceneCode.condition1IsTrue_0;
gdjs.New_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9317764);
}
}}
if (gdjs.New_32sceneCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.New_32sceneCode.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.New_32sceneCode.eventsList17 = function(runtimeScene) {

{


gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("ShowNumbers")) == 0;
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.New_32sceneCode.GDLoopCounterTextObjects2, gdjs.New_32sceneCode.GDLoopCounterTextObjects3);

{for(var i = 0, len = gdjs.New_32sceneCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDLoopCounterTextObjects3[i].hide();
}
}}

}


{


gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("ShowNumbers")) == 1;
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.New_32sceneCode.GDLoopCounterTextObjects2, gdjs.New_32sceneCode.GDLoopCounterTextObjects3);

{for(var i = 0, len = gdjs.New_32sceneCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDLoopCounterTextObjects3[i].hide(false);
}
}}

}


};gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDQuestionMarkObjects1Objects = Hashtable.newFrom({"QuestionMark": gdjs.New_32sceneCode.GDQuestionMarkObjects1});gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDQuestionMarkObjects1Objects = Hashtable.newFrom({"QuestionMark": gdjs.New_32sceneCode.GDQuestionMarkObjects1});gdjs.New_32sceneCode.eventsList18 = function(runtimeScene) {

{


gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("WhiteSquare"), gdjs.New_32sceneCode.GDWhiteSquareObjects1);
{gdjs.evtsExt__CreateMultipleCopiesOfObject__CreateMultipleCopiesOfObject.func(runtimeScene, gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDWhiteSquareObjects1Objects, 10, 20, 0, 0, 0, 0, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("RandomButton"), gdjs.New_32sceneCode.GDRandomButtonObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
gdjs.New_32sceneCode.condition1IsTrue_0.val = false;
gdjs.New_32sceneCode.condition2IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDRandomButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.New_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.New_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.New_32sceneCode.condition1IsTrue_0.val ) {
{
{gdjs.New_32sceneCode.conditionTrue_1 = gdjs.New_32sceneCode.condition2IsTrue_0;
gdjs.New_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9275516);
}
}}
}
if (gdjs.New_32sceneCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DarksAndGreysRemovedButton"), gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("DarksRemovedButton"), gdjs.New_32sceneCode.GDDarksRemovedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("GreysRemovedButton"), gdjs.New_32sceneCode.GDGreysRemovedButtonObjects1);
/* Reuse gdjs.New_32sceneCode.GDRandomButtonObjects1 */
{for(var i = 0, len = gdjs.New_32sceneCode.GDRandomButtonObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDRandomButtonObjects1[i].setAnimationName("Selected");
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDDarksRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDDarksRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDGreysRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDGreysRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}
{ //Subevents
gdjs.New_32sceneCode.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("DarksRemovedButton"), gdjs.New_32sceneCode.GDDarksRemovedButtonObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
gdjs.New_32sceneCode.condition1IsTrue_0.val = false;
gdjs.New_32sceneCode.condition2IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDDarksRemovedButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.New_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.New_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.New_32sceneCode.condition1IsTrue_0.val ) {
{
{gdjs.New_32sceneCode.conditionTrue_1 = gdjs.New_32sceneCode.condition2IsTrue_0;
gdjs.New_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9282068);
}
}}
}
if (gdjs.New_32sceneCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DarksAndGreysRemovedButton"), gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects1);
/* Reuse gdjs.New_32sceneCode.GDDarksRemovedButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("GreysRemovedButton"), gdjs.New_32sceneCode.GDGreysRemovedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("RandomButton"), gdjs.New_32sceneCode.GDRandomButtonObjects1);
{for(var i = 0, len = gdjs.New_32sceneCode.GDDarksRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDDarksRemovedButtonObjects1[i].setAnimationName("Selected");
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDRandomButtonObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDRandomButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDGreysRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDGreysRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}
{ //Subevents
gdjs.New_32sceneCode.eventsList6(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("GreysRemovedButton"), gdjs.New_32sceneCode.GDGreysRemovedButtonObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
gdjs.New_32sceneCode.condition1IsTrue_0.val = false;
gdjs.New_32sceneCode.condition2IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDGreysRemovedButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.New_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.New_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.New_32sceneCode.condition1IsTrue_0.val ) {
{
{gdjs.New_32sceneCode.conditionTrue_1 = gdjs.New_32sceneCode.condition2IsTrue_0;
gdjs.New_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9293820);
}
}}
}
if (gdjs.New_32sceneCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DarksAndGreysRemovedButton"), gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("DarksRemovedButton"), gdjs.New_32sceneCode.GDDarksRemovedButtonObjects1);
/* Reuse gdjs.New_32sceneCode.GDGreysRemovedButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("RandomButton"), gdjs.New_32sceneCode.GDRandomButtonObjects1);
{for(var i = 0, len = gdjs.New_32sceneCode.GDGreysRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDGreysRemovedButtonObjects1[i].setAnimationName("Selected");
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDRandomButtonObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDRandomButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDDarksRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDDarksRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}
{ //Subevents
gdjs.New_32sceneCode.eventsList10(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("DarksAndGreysRemovedButton"), gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
gdjs.New_32sceneCode.condition1IsTrue_0.val = false;
gdjs.New_32sceneCode.condition2IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDDarksAndGreysRemovedButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.New_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.New_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.New_32sceneCode.condition1IsTrue_0.val ) {
{
{gdjs.New_32sceneCode.conditionTrue_1 = gdjs.New_32sceneCode.condition2IsTrue_0;
gdjs.New_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9304748);
}
}}
}
if (gdjs.New_32sceneCode.condition2IsTrue_0.val) {
/* Reuse gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("DarksRemovedButton"), gdjs.New_32sceneCode.GDDarksRemovedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("GreysRemovedButton"), gdjs.New_32sceneCode.GDGreysRemovedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("RandomButton"), gdjs.New_32sceneCode.GDRandomButtonObjects1);
{for(var i = 0, len = gdjs.New_32sceneCode.GDGreysRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDGreysRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDRandomButtonObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDRandomButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDDarksRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDDarksRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects1[i].setAnimationName("Selected");
}
}
{ //Subevents
gdjs.New_32sceneCode.eventsList14(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("ShowHideNumbersButton"), gdjs.New_32sceneCode.GDShowHideNumbersButtonObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDShowHideNumbersButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.New_32sceneCode.eventsList16(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LoopCounterText"), gdjs.New_32sceneCode.GDLoopCounterTextObjects1);

for(gdjs.New_32sceneCode.forEachIndex2 = 0;gdjs.New_32sceneCode.forEachIndex2 < gdjs.New_32sceneCode.GDLoopCounterTextObjects1.length;++gdjs.New_32sceneCode.forEachIndex2) {
gdjs.New_32sceneCode.GDLoopCounterTextObjects2.length = 0;


gdjs.New_32sceneCode.forEachTemporary2 = gdjs.New_32sceneCode.GDLoopCounterTextObjects1[gdjs.New_32sceneCode.forEachIndex2];
gdjs.New_32sceneCode.GDLoopCounterTextObjects2.push(gdjs.New_32sceneCode.forEachTemporary2);
if (true) {

{ //Subevents: 
gdjs.New_32sceneCode.eventsList17(runtimeScene);} //Subevents end.
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("QuestionMark"), gdjs.New_32sceneCode.GDQuestionMarkObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDQuestionMarkObjects1Objects, runtimeScene, true, false);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "Explanation");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("QuestionMark"), gdjs.New_32sceneCode.GDQuestionMarkObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDQuestionMarkObjects1Objects, runtimeScene, true, true);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Explanation");
}}

}


};

gdjs.New_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.New_32sceneCode.GDWhiteSquareObjects1.length = 0;
gdjs.New_32sceneCode.GDWhiteSquareObjects2.length = 0;
gdjs.New_32sceneCode.GDWhiteSquareObjects3.length = 0;
gdjs.New_32sceneCode.GDWhiteSquareObjects4.length = 0;
gdjs.New_32sceneCode.GDWhiteSquareObjects5.length = 0;
gdjs.New_32sceneCode.GDWhiteSquareObjects6.length = 0;
gdjs.New_32sceneCode.GDShowHideNumbersButtonObjects1.length = 0;
gdjs.New_32sceneCode.GDShowHideNumbersButtonObjects2.length = 0;
gdjs.New_32sceneCode.GDShowHideNumbersButtonObjects3.length = 0;
gdjs.New_32sceneCode.GDShowHideNumbersButtonObjects4.length = 0;
gdjs.New_32sceneCode.GDShowHideNumbersButtonObjects5.length = 0;
gdjs.New_32sceneCode.GDShowHideNumbersButtonObjects6.length = 0;
gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects1.length = 0;
gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects2.length = 0;
gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects3.length = 0;
gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects4.length = 0;
gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects5.length = 0;
gdjs.New_32sceneCode.GDDarksAndGreysRemovedButtonObjects6.length = 0;
gdjs.New_32sceneCode.GDGreysRemovedButtonObjects1.length = 0;
gdjs.New_32sceneCode.GDGreysRemovedButtonObjects2.length = 0;
gdjs.New_32sceneCode.GDGreysRemovedButtonObjects3.length = 0;
gdjs.New_32sceneCode.GDGreysRemovedButtonObjects4.length = 0;
gdjs.New_32sceneCode.GDGreysRemovedButtonObjects5.length = 0;
gdjs.New_32sceneCode.GDGreysRemovedButtonObjects6.length = 0;
gdjs.New_32sceneCode.GDDarksRemovedButtonObjects1.length = 0;
gdjs.New_32sceneCode.GDDarksRemovedButtonObjects2.length = 0;
gdjs.New_32sceneCode.GDDarksRemovedButtonObjects3.length = 0;
gdjs.New_32sceneCode.GDDarksRemovedButtonObjects4.length = 0;
gdjs.New_32sceneCode.GDDarksRemovedButtonObjects5.length = 0;
gdjs.New_32sceneCode.GDDarksRemovedButtonObjects6.length = 0;
gdjs.New_32sceneCode.GDRandomButtonObjects1.length = 0;
gdjs.New_32sceneCode.GDRandomButtonObjects2.length = 0;
gdjs.New_32sceneCode.GDRandomButtonObjects3.length = 0;
gdjs.New_32sceneCode.GDRandomButtonObjects4.length = 0;
gdjs.New_32sceneCode.GDRandomButtonObjects5.length = 0;
gdjs.New_32sceneCode.GDRandomButtonObjects6.length = 0;
gdjs.New_32sceneCode.GDLoopCounterTextObjects1.length = 0;
gdjs.New_32sceneCode.GDLoopCounterTextObjects2.length = 0;
gdjs.New_32sceneCode.GDLoopCounterTextObjects3.length = 0;
gdjs.New_32sceneCode.GDLoopCounterTextObjects4.length = 0;
gdjs.New_32sceneCode.GDLoopCounterTextObjects5.length = 0;
gdjs.New_32sceneCode.GDLoopCounterTextObjects6.length = 0;
gdjs.New_32sceneCode.GDShowHideNumbersTextObjects1.length = 0;
gdjs.New_32sceneCode.GDShowHideNumbersTextObjects2.length = 0;
gdjs.New_32sceneCode.GDShowHideNumbersTextObjects3.length = 0;
gdjs.New_32sceneCode.GDShowHideNumbersTextObjects4.length = 0;
gdjs.New_32sceneCode.GDShowHideNumbersTextObjects5.length = 0;
gdjs.New_32sceneCode.GDShowHideNumbersTextObjects6.length = 0;
gdjs.New_32sceneCode.GDDarksAndGreysRemovedTextObjects1.length = 0;
gdjs.New_32sceneCode.GDDarksAndGreysRemovedTextObjects2.length = 0;
gdjs.New_32sceneCode.GDDarksAndGreysRemovedTextObjects3.length = 0;
gdjs.New_32sceneCode.GDDarksAndGreysRemovedTextObjects4.length = 0;
gdjs.New_32sceneCode.GDDarksAndGreysRemovedTextObjects5.length = 0;
gdjs.New_32sceneCode.GDDarksAndGreysRemovedTextObjects6.length = 0;
gdjs.New_32sceneCode.GDGreysRemovedTextObjects1.length = 0;
gdjs.New_32sceneCode.GDGreysRemovedTextObjects2.length = 0;
gdjs.New_32sceneCode.GDGreysRemovedTextObjects3.length = 0;
gdjs.New_32sceneCode.GDGreysRemovedTextObjects4.length = 0;
gdjs.New_32sceneCode.GDGreysRemovedTextObjects5.length = 0;
gdjs.New_32sceneCode.GDGreysRemovedTextObjects6.length = 0;
gdjs.New_32sceneCode.GDDarksRemovedTextObjects1.length = 0;
gdjs.New_32sceneCode.GDDarksRemovedTextObjects2.length = 0;
gdjs.New_32sceneCode.GDDarksRemovedTextObjects3.length = 0;
gdjs.New_32sceneCode.GDDarksRemovedTextObjects4.length = 0;
gdjs.New_32sceneCode.GDDarksRemovedTextObjects5.length = 0;
gdjs.New_32sceneCode.GDDarksRemovedTextObjects6.length = 0;
gdjs.New_32sceneCode.GDRandomColorsTextObjects1.length = 0;
gdjs.New_32sceneCode.GDRandomColorsTextObjects2.length = 0;
gdjs.New_32sceneCode.GDRandomColorsTextObjects3.length = 0;
gdjs.New_32sceneCode.GDRandomColorsTextObjects4.length = 0;
gdjs.New_32sceneCode.GDRandomColorsTextObjects5.length = 0;
gdjs.New_32sceneCode.GDRandomColorsTextObjects6.length = 0;
gdjs.New_32sceneCode.GDExplanationTextObjects1.length = 0;
gdjs.New_32sceneCode.GDExplanationTextObjects2.length = 0;
gdjs.New_32sceneCode.GDExplanationTextObjects3.length = 0;
gdjs.New_32sceneCode.GDExplanationTextObjects4.length = 0;
gdjs.New_32sceneCode.GDExplanationTextObjects5.length = 0;
gdjs.New_32sceneCode.GDExplanationTextObjects6.length = 0;
gdjs.New_32sceneCode.GDExplanationBoxObjects1.length = 0;
gdjs.New_32sceneCode.GDExplanationBoxObjects2.length = 0;
gdjs.New_32sceneCode.GDExplanationBoxObjects3.length = 0;
gdjs.New_32sceneCode.GDExplanationBoxObjects4.length = 0;
gdjs.New_32sceneCode.GDExplanationBoxObjects5.length = 0;
gdjs.New_32sceneCode.GDExplanationBoxObjects6.length = 0;
gdjs.New_32sceneCode.GDQuestionMarkObjects1.length = 0;
gdjs.New_32sceneCode.GDQuestionMarkObjects2.length = 0;
gdjs.New_32sceneCode.GDQuestionMarkObjects3.length = 0;
gdjs.New_32sceneCode.GDQuestionMarkObjects4.length = 0;
gdjs.New_32sceneCode.GDQuestionMarkObjects5.length = 0;
gdjs.New_32sceneCode.GDQuestionMarkObjects6.length = 0;

gdjs.New_32sceneCode.eventsList18(runtimeScene);
return;

}

gdjs['New_32sceneCode'] = gdjs.New_32sceneCode;
