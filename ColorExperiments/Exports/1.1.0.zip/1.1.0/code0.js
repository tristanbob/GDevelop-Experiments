gdjs.ColorGeneratorCode = {};
gdjs.ColorGeneratorCode.GDWhiteSquareObjects4_1final = [];

gdjs.ColorGeneratorCode.forEachIndex2 = 0;

gdjs.ColorGeneratorCode.forEachIndex3 = 0;

gdjs.ColorGeneratorCode.forEachObjects2 = [];

gdjs.ColorGeneratorCode.forEachObjects3 = [];

gdjs.ColorGeneratorCode.forEachTemporary2 = null;

gdjs.ColorGeneratorCode.forEachTemporary3 = null;

gdjs.ColorGeneratorCode.forEachTotalCount2 = 0;

gdjs.ColorGeneratorCode.forEachTotalCount3 = 0;

gdjs.ColorGeneratorCode.stopDoWhile4 = false;

gdjs.ColorGeneratorCode.GDWhiteSquareObjects1= [];
gdjs.ColorGeneratorCode.GDWhiteSquareObjects2= [];
gdjs.ColorGeneratorCode.GDWhiteSquareObjects3= [];
gdjs.ColorGeneratorCode.GDWhiteSquareObjects4= [];
gdjs.ColorGeneratorCode.GDWhiteSquareObjects5= [];
gdjs.ColorGeneratorCode.GDShowHideNumbersButtonObjects1= [];
gdjs.ColorGeneratorCode.GDShowHideNumbersButtonObjects2= [];
gdjs.ColorGeneratorCode.GDShowHideNumbersButtonObjects3= [];
gdjs.ColorGeneratorCode.GDShowHideNumbersButtonObjects4= [];
gdjs.ColorGeneratorCode.GDShowHideNumbersButtonObjects5= [];
gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1= [];
gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects2= [];
gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects3= [];
gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects4= [];
gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects5= [];
gdjs.ColorGeneratorCode.GDPastelsButtonObjects1= [];
gdjs.ColorGeneratorCode.GDPastelsButtonObjects2= [];
gdjs.ColorGeneratorCode.GDPastelsButtonObjects3= [];
gdjs.ColorGeneratorCode.GDPastelsButtonObjects4= [];
gdjs.ColorGeneratorCode.GDPastelsButtonObjects5= [];
gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1= [];
gdjs.ColorGeneratorCode.GDPureHuesButtonObjects2= [];
gdjs.ColorGeneratorCode.GDPureHuesButtonObjects3= [];
gdjs.ColorGeneratorCode.GDPureHuesButtonObjects4= [];
gdjs.ColorGeneratorCode.GDPureHuesButtonObjects5= [];
gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1= [];
gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects2= [];
gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects3= [];
gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects4= [];
gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects5= [];
gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1= [];
gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects2= [];
gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects3= [];
gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects4= [];
gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects5= [];
gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1= [];
gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects2= [];
gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects3= [];
gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects4= [];
gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects5= [];
gdjs.ColorGeneratorCode.GDRandomButtonObjects1= [];
gdjs.ColorGeneratorCode.GDRandomButtonObjects2= [];
gdjs.ColorGeneratorCode.GDRandomButtonObjects3= [];
gdjs.ColorGeneratorCode.GDRandomButtonObjects4= [];
gdjs.ColorGeneratorCode.GDRandomButtonObjects5= [];
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects1= [];
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2= [];
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3= [];
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects4= [];
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects5= [];
gdjs.ColorGeneratorCode.GDShowHideNumbersTextObjects1= [];
gdjs.ColorGeneratorCode.GDShowHideNumbersTextObjects2= [];
gdjs.ColorGeneratorCode.GDShowHideNumbersTextObjects3= [];
gdjs.ColorGeneratorCode.GDShowHideNumbersTextObjects4= [];
gdjs.ColorGeneratorCode.GDShowHideNumbersTextObjects5= [];
gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedTextObjects1= [];
gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedTextObjects2= [];
gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedTextObjects3= [];
gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedTextObjects4= [];
gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedTextObjects5= [];
gdjs.ColorGeneratorCode.GDGreyScaleTextObjects1= [];
gdjs.ColorGeneratorCode.GDGreyScaleTextObjects2= [];
gdjs.ColorGeneratorCode.GDGreyScaleTextObjects3= [];
gdjs.ColorGeneratorCode.GDGreyScaleTextObjects4= [];
gdjs.ColorGeneratorCode.GDGreyScaleTextObjects5= [];
gdjs.ColorGeneratorCode.GDPureHuesTextObjects1= [];
gdjs.ColorGeneratorCode.GDPureHuesTextObjects2= [];
gdjs.ColorGeneratorCode.GDPureHuesTextObjects3= [];
gdjs.ColorGeneratorCode.GDPureHuesTextObjects4= [];
gdjs.ColorGeneratorCode.GDPureHuesTextObjects5= [];
gdjs.ColorGeneratorCode.GDPastelsTextObjects1= [];
gdjs.ColorGeneratorCode.GDPastelsTextObjects2= [];
gdjs.ColorGeneratorCode.GDPastelsTextObjects3= [];
gdjs.ColorGeneratorCode.GDPastelsTextObjects4= [];
gdjs.ColorGeneratorCode.GDPastelsTextObjects5= [];
gdjs.ColorGeneratorCode.GDGreysRemovedTextObjects1= [];
gdjs.ColorGeneratorCode.GDGreysRemovedTextObjects2= [];
gdjs.ColorGeneratorCode.GDGreysRemovedTextObjects3= [];
gdjs.ColorGeneratorCode.GDGreysRemovedTextObjects4= [];
gdjs.ColorGeneratorCode.GDGreysRemovedTextObjects5= [];
gdjs.ColorGeneratorCode.GDDarksRemovedTextObjects1= [];
gdjs.ColorGeneratorCode.GDDarksRemovedTextObjects2= [];
gdjs.ColorGeneratorCode.GDDarksRemovedTextObjects3= [];
gdjs.ColorGeneratorCode.GDDarksRemovedTextObjects4= [];
gdjs.ColorGeneratorCode.GDDarksRemovedTextObjects5= [];
gdjs.ColorGeneratorCode.GDRandomColorsTextObjects1= [];
gdjs.ColorGeneratorCode.GDRandomColorsTextObjects2= [];
gdjs.ColorGeneratorCode.GDRandomColorsTextObjects3= [];
gdjs.ColorGeneratorCode.GDRandomColorsTextObjects4= [];
gdjs.ColorGeneratorCode.GDRandomColorsTextObjects5= [];
gdjs.ColorGeneratorCode.GDExplanationTextObjects1= [];
gdjs.ColorGeneratorCode.GDExplanationTextObjects2= [];
gdjs.ColorGeneratorCode.GDExplanationTextObjects3= [];
gdjs.ColorGeneratorCode.GDExplanationTextObjects4= [];
gdjs.ColorGeneratorCode.GDExplanationTextObjects5= [];
gdjs.ColorGeneratorCode.GDExplanationBoxObjects1= [];
gdjs.ColorGeneratorCode.GDExplanationBoxObjects2= [];
gdjs.ColorGeneratorCode.GDExplanationBoxObjects3= [];
gdjs.ColorGeneratorCode.GDExplanationBoxObjects4= [];
gdjs.ColorGeneratorCode.GDExplanationBoxObjects5= [];
gdjs.ColorGeneratorCode.GDQuestionMarkObjects1= [];
gdjs.ColorGeneratorCode.GDQuestionMarkObjects2= [];
gdjs.ColorGeneratorCode.GDQuestionMarkObjects3= [];
gdjs.ColorGeneratorCode.GDQuestionMarkObjects4= [];
gdjs.ColorGeneratorCode.GDQuestionMarkObjects5= [];

gdjs.ColorGeneratorCode.conditionTrue_0 = {val:false};
gdjs.ColorGeneratorCode.condition0IsTrue_0 = {val:false};
gdjs.ColorGeneratorCode.condition1IsTrue_0 = {val:false};
gdjs.ColorGeneratorCode.condition2IsTrue_0 = {val:false};
gdjs.ColorGeneratorCode.condition3IsTrue_0 = {val:false};
gdjs.ColorGeneratorCode.conditionTrue_1 = {val:false};
gdjs.ColorGeneratorCode.condition0IsTrue_1 = {val:false};
gdjs.ColorGeneratorCode.condition1IsTrue_1 = {val:false};
gdjs.ColorGeneratorCode.condition2IsTrue_1 = {val:false};
gdjs.ColorGeneratorCode.condition3IsTrue_1 = {val:false};
gdjs.ColorGeneratorCode.conditionTrue_2 = {val:false};
gdjs.ColorGeneratorCode.condition0IsTrue_2 = {val:false};
gdjs.ColorGeneratorCode.condition1IsTrue_2 = {val:false};
gdjs.ColorGeneratorCode.condition2IsTrue_2 = {val:false};
gdjs.ColorGeneratorCode.condition3IsTrue_2 = {val:false};


gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDWhiteSquareObjects1Objects = Hashtable.newFrom({"WhiteSquare": gdjs.ColorGeneratorCode.GDWhiteSquareObjects1});gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDRandomButtonObjects1Objects = Hashtable.newFrom({"RandomButton": gdjs.ColorGeneratorCode.GDRandomButtonObjects1});gdjs.ColorGeneratorCode.eventsList0 = function(runtimeScene) {

};gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDLoopCounterTextObjects2Objects = Hashtable.newFrom({"LoopCounterText": gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2});gdjs.ColorGeneratorCode.eventsList1 = function(runtimeScene) {

};gdjs.ColorGeneratorCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("LoopCounterText"), gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2);

for(gdjs.ColorGeneratorCode.forEachIndex3 = 0;gdjs.ColorGeneratorCode.forEachIndex3 < gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2.length;++gdjs.ColorGeneratorCode.forEachIndex3) {
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length = 0;


gdjs.ColorGeneratorCode.forEachTemporary3 = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2[gdjs.ColorGeneratorCode.forEachIndex3];
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.push(gdjs.ColorGeneratorCode.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3[i].deleteFromScene(runtimeScene);
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("WhiteSquare"), gdjs.ColorGeneratorCode.GDWhiteSquareObjects1);

for(gdjs.ColorGeneratorCode.forEachIndex2 = 0;gdjs.ColorGeneratorCode.forEachIndex2 < gdjs.ColorGeneratorCode.GDWhiteSquareObjects1.length;++gdjs.ColorGeneratorCode.forEachIndex2) {
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2.length = 0;

gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length = 0;


gdjs.ColorGeneratorCode.forEachTemporary2 = gdjs.ColorGeneratorCode.GDWhiteSquareObjects1[gdjs.ColorGeneratorCode.forEachIndex2];
gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.push(gdjs.ColorGeneratorCode.forEachTemporary2);
if (true) {
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].setColor(gdjs.evtTools.common.toString(gdjs.randomInRange(0, 255)) + ";" + gdjs.evtTools.common.toString(gdjs.randomInRange(0, 255)) + ";" + gdjs.evtTools.common.toString(gdjs.randomInRange(0, 255)));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("LoopCounter")).setNumber(1);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDLoopCounterTextObjects2Objects, (( gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length === 0 ) ? 0 :gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[0].getPointX("Center")) - 10, (( gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length === 0 ) ? 0 :gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[0].getPointY("")) + 10, "");
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2[i].setString(gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[0].getVariables()).get("LoopCounter")))));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2[i].setZOrder(100);
}
}}
}

}


};gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDDarksRemovedButtonObjects1Objects = Hashtable.newFrom({"DarksRemovedButton": gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1});gdjs.ColorGeneratorCode.eventsList3 = function(runtimeScene) {

};gdjs.ColorGeneratorCode.eventsList4 = function(runtimeScene) {

};gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDLoopCounterTextObjects3Objects = Hashtable.newFrom({"LoopCounterText": gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3});gdjs.ColorGeneratorCode.eventsList5 = function(runtimeScene) {

{


gdjs.ColorGeneratorCode.stopDoWhile4 = false;
do {gdjs.copyArray(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2, gdjs.ColorGeneratorCode.GDWhiteSquareObjects4);

gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
{
{gdjs.ColorGeneratorCode.conditionTrue_1 = gdjs.ColorGeneratorCode.condition0IsTrue_0;
gdjs.ColorGeneratorCode.conditionTrue_1.val = ((gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[0].getVariables()).get("RedValue"))) + (gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[0].getVariables()).get("GreenValue"))) + (gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[0].getVariables()).get("BlueValue"))) < 255);
}
}if (gdjs.ColorGeneratorCode.condition0IsTrue_0.val) {
if (true) {
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("RedValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("GreenValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("BlueValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("LoopCounter")).add(1);
}
}
{ //Subevents: 
gdjs.ColorGeneratorCode.eventsList4(runtimeScene);} //Subevents end.
}
} else gdjs.ColorGeneratorCode.stopDoWhile4 = true; 
} while ( !gdjs.ColorGeneratorCode.stopDoWhile4 );

}


{



}


{


{
gdjs.copyArray(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2, gdjs.ColorGeneratorCode.GDWhiteSquareObjects3);

gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length = 0;

{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].setColor(gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].getVariables().get("RedValue")))) + ";" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].getVariables().get("GreenValue")))) + ";" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].getVariables().get("BlueValue")))));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDLoopCounterTextObjects3Objects, (( gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length === 0 ) ? 0 :gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[0].getPointX("Center")) - 10, (( gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length === 0 ) ? 0 :gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[0].getPointY("")) + 10, "");
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3[i].setString(gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[0].getVariables()).get("LoopCounter")))));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3[i].setZOrder(100);
}
}}

}


};gdjs.ColorGeneratorCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("LoopCounterText"), gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2);

for(gdjs.ColorGeneratorCode.forEachIndex3 = 0;gdjs.ColorGeneratorCode.forEachIndex3 < gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2.length;++gdjs.ColorGeneratorCode.forEachIndex3) {
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length = 0;


gdjs.ColorGeneratorCode.forEachTemporary3 = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2[gdjs.ColorGeneratorCode.forEachIndex3];
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.push(gdjs.ColorGeneratorCode.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3[i].deleteFromScene(runtimeScene);
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("WhiteSquare"), gdjs.ColorGeneratorCode.GDWhiteSquareObjects1);

for(gdjs.ColorGeneratorCode.forEachIndex2 = 0;gdjs.ColorGeneratorCode.forEachIndex2 < gdjs.ColorGeneratorCode.GDWhiteSquareObjects1.length;++gdjs.ColorGeneratorCode.forEachIndex2) {
gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length = 0;


gdjs.ColorGeneratorCode.forEachTemporary2 = gdjs.ColorGeneratorCode.GDWhiteSquareObjects1[gdjs.ColorGeneratorCode.forEachIndex2];
gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.push(gdjs.ColorGeneratorCode.forEachTemporary2);
if (true) {
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("GreenValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("BlueValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("RedValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("LoopCounter")).setNumber(0);
}
}
{ //Subevents: 
gdjs.ColorGeneratorCode.eventsList5(runtimeScene);} //Subevents end.
}
}

}


};gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDGreysRemovedButtonObjects1Objects = Hashtable.newFrom({"GreysRemovedButton": gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1});gdjs.ColorGeneratorCode.eventsList7 = function(runtimeScene) {

};gdjs.ColorGeneratorCode.eventsList8 = function(runtimeScene) {

};gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDLoopCounterTextObjects3Objects = Hashtable.newFrom({"LoopCounterText": gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3});gdjs.ColorGeneratorCode.eventsList9 = function(runtimeScene) {

{


gdjs.ColorGeneratorCode.stopDoWhile4 = false;
do {gdjs.copyArray(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2, gdjs.ColorGeneratorCode.GDWhiteSquareObjects4);

gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
{
{gdjs.ColorGeneratorCode.conditionTrue_1 = gdjs.ColorGeneratorCode.condition0IsTrue_0;
gdjs.ColorGeneratorCode.conditionTrue_1.val = (Math.max(Math.max((gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[0].getVariables()).get("RedValue"))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[0].getVariables()).get("BlueValue")))), Math.max((gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[0].getVariables()).get("GreenValue"))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[0].getVariables()).get("BlueValue"))))) - Math.min(Math.min((gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[0].getVariables()).get("RedValue"))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[0].getVariables()).get("BlueValue")))), Math.min((gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[0].getVariables()).get("GreenValue"))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[0].getVariables()).get("BlueValue"))))) < 128);
}
}if (gdjs.ColorGeneratorCode.condition0IsTrue_0.val) {
if (true) {
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("RedValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("GreenValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("BlueValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("LoopCounter")).add(1);
}
}
{ //Subevents: 
gdjs.ColorGeneratorCode.eventsList8(runtimeScene);} //Subevents end.
}
} else gdjs.ColorGeneratorCode.stopDoWhile4 = true; 
} while ( !gdjs.ColorGeneratorCode.stopDoWhile4 );

}


{



}


{


{
gdjs.copyArray(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2, gdjs.ColorGeneratorCode.GDWhiteSquareObjects3);

gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length = 0;

{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].setColor(gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].getVariables().get("RedValue")))) + ";" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].getVariables().get("GreenValue")))) + ";" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].getVariables().get("BlueValue")))));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDLoopCounterTextObjects3Objects, (( gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length === 0 ) ? 0 :gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[0].getPointX("Center")) - 10, (( gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length === 0 ) ? 0 :gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[0].getPointY("")) + 10, "");
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3[i].setString(gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[0].getVariables()).get("LoopCounter")))));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3[i].setZOrder(100);
}
}}

}


};gdjs.ColorGeneratorCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("LoopCounterText"), gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2);

for(gdjs.ColorGeneratorCode.forEachIndex3 = 0;gdjs.ColorGeneratorCode.forEachIndex3 < gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2.length;++gdjs.ColorGeneratorCode.forEachIndex3) {
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length = 0;


gdjs.ColorGeneratorCode.forEachTemporary3 = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2[gdjs.ColorGeneratorCode.forEachIndex3];
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.push(gdjs.ColorGeneratorCode.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3[i].deleteFromScene(runtimeScene);
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("WhiteSquare"), gdjs.ColorGeneratorCode.GDWhiteSquareObjects1);

for(gdjs.ColorGeneratorCode.forEachIndex2 = 0;gdjs.ColorGeneratorCode.forEachIndex2 < gdjs.ColorGeneratorCode.GDWhiteSquareObjects1.length;++gdjs.ColorGeneratorCode.forEachIndex2) {
gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length = 0;


gdjs.ColorGeneratorCode.forEachTemporary2 = gdjs.ColorGeneratorCode.GDWhiteSquareObjects1[gdjs.ColorGeneratorCode.forEachIndex2];
gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.push(gdjs.ColorGeneratorCode.forEachTemporary2);
if (true) {
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("GreenValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("BlueValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("RedValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("LoopCounter")).setNumber(0);
}
}
{ //Subevents: 
gdjs.ColorGeneratorCode.eventsList9(runtimeScene);} //Subevents end.
}
}

}


};gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDDarksAndGreysRemovedButtonObjects1Objects = Hashtable.newFrom({"DarksAndGreysRemovedButton": gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1});gdjs.ColorGeneratorCode.eventsList11 = function(runtimeScene) {

};gdjs.ColorGeneratorCode.eventsList12 = function(runtimeScene) {

};gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDLoopCounterTextObjects3Objects = Hashtable.newFrom({"LoopCounterText": gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3});gdjs.ColorGeneratorCode.eventsList13 = function(runtimeScene) {

{


gdjs.ColorGeneratorCode.stopDoWhile4 = false;
do {gdjs.copyArray(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2, gdjs.ColorGeneratorCode.GDWhiteSquareObjects4);

gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
{
{gdjs.ColorGeneratorCode.conditionTrue_1 = gdjs.ColorGeneratorCode.condition0IsTrue_0;
gdjs.ColorGeneratorCode.GDWhiteSquareObjects4_1final.length = 0;gdjs.ColorGeneratorCode.condition0IsTrue_1.val = false;
gdjs.ColorGeneratorCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2, gdjs.ColorGeneratorCode.GDWhiteSquareObjects5);

{gdjs.ColorGeneratorCode.conditionTrue_2 = gdjs.ColorGeneratorCode.condition0IsTrue_1;
gdjs.ColorGeneratorCode.conditionTrue_2.val = ((gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects5[0].getVariables()).get("RedValue"))) + (gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects5[0].getVariables()).get("GreenValue"))) + (gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects5[0].getVariables()).get("BlueValue"))) < 255);
}
if( gdjs.ColorGeneratorCode.condition0IsTrue_1.val ) {
    gdjs.ColorGeneratorCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.ColorGeneratorCode.GDWhiteSquareObjects5.length;j<jLen;++j) {
        if ( gdjs.ColorGeneratorCode.GDWhiteSquareObjects4_1final.indexOf(gdjs.ColorGeneratorCode.GDWhiteSquareObjects5[j]) === -1 )
            gdjs.ColorGeneratorCode.GDWhiteSquareObjects4_1final.push(gdjs.ColorGeneratorCode.GDWhiteSquareObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2, gdjs.ColorGeneratorCode.GDWhiteSquareObjects5);

{gdjs.ColorGeneratorCode.conditionTrue_2 = gdjs.ColorGeneratorCode.condition1IsTrue_1;
gdjs.ColorGeneratorCode.conditionTrue_2.val = (Math.max(Math.max((gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects5[0].getVariables()).get("RedValue"))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects5[0].getVariables()).get("BlueValue")))), Math.max((gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects5[0].getVariables()).get("GreenValue"))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects5[0].getVariables()).get("BlueValue"))))) - Math.min(Math.min((gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects5[0].getVariables()).get("RedValue"))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects5[0].getVariables()).get("BlueValue")))), Math.min((gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects5[0].getVariables()).get("GreenValue"))), (gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects5[0].getVariables()).get("BlueValue"))))) < 128);
}
if( gdjs.ColorGeneratorCode.condition1IsTrue_1.val ) {
    gdjs.ColorGeneratorCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.ColorGeneratorCode.GDWhiteSquareObjects5.length;j<jLen;++j) {
        if ( gdjs.ColorGeneratorCode.GDWhiteSquareObjects4_1final.indexOf(gdjs.ColorGeneratorCode.GDWhiteSquareObjects5[j]) === -1 )
            gdjs.ColorGeneratorCode.GDWhiteSquareObjects4_1final.push(gdjs.ColorGeneratorCode.GDWhiteSquareObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4_1final, gdjs.ColorGeneratorCode.GDWhiteSquareObjects4);
}
}
}if (gdjs.ColorGeneratorCode.condition0IsTrue_0.val) {
if (true) {
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("RedValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("GreenValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("BlueValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("LoopCounter")).add(1);
}
}
{ //Subevents: 
gdjs.ColorGeneratorCode.eventsList12(runtimeScene);} //Subevents end.
}
} else gdjs.ColorGeneratorCode.stopDoWhile4 = true; 
} while ( !gdjs.ColorGeneratorCode.stopDoWhile4 );

}


{



}


{


{
gdjs.copyArray(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2, gdjs.ColorGeneratorCode.GDWhiteSquareObjects3);

gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length = 0;

{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].setColor(gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].getVariables().get("RedValue")))) + ";" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].getVariables().get("GreenValue")))) + ";" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].getVariables().get("BlueValue")))));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDLoopCounterTextObjects3Objects, (( gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length === 0 ) ? 0 :gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[0].getPointX("Center")) - 10, (( gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length === 0 ) ? 0 :gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[0].getPointY("")) + 10, "");
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3[i].setString(gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[0].getVariables()).get("LoopCounter")))));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3[i].setZOrder(100);
}
}}

}


};gdjs.ColorGeneratorCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("LoopCounterText"), gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2);

for(gdjs.ColorGeneratorCode.forEachIndex3 = 0;gdjs.ColorGeneratorCode.forEachIndex3 < gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2.length;++gdjs.ColorGeneratorCode.forEachIndex3) {
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length = 0;


gdjs.ColorGeneratorCode.forEachTemporary3 = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2[gdjs.ColorGeneratorCode.forEachIndex3];
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.push(gdjs.ColorGeneratorCode.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3[i].deleteFromScene(runtimeScene);
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("WhiteSquare"), gdjs.ColorGeneratorCode.GDWhiteSquareObjects1);

for(gdjs.ColorGeneratorCode.forEachIndex2 = 0;gdjs.ColorGeneratorCode.forEachIndex2 < gdjs.ColorGeneratorCode.GDWhiteSquareObjects1.length;++gdjs.ColorGeneratorCode.forEachIndex2) {
gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length = 0;


gdjs.ColorGeneratorCode.forEachTemporary2 = gdjs.ColorGeneratorCode.GDWhiteSquareObjects1[gdjs.ColorGeneratorCode.forEachIndex2];
gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.push(gdjs.ColorGeneratorCode.forEachTemporary2);
if (true) {
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("GreenValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("BlueValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("RedValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("LoopCounter")).setNumber(0);
}
}
{ //Subevents: 
gdjs.ColorGeneratorCode.eventsList13(runtimeScene);} //Subevents end.
}
}

}


};gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDPureHuesButtonObjects1Objects = Hashtable.newFrom({"PureHuesButton": gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1});gdjs.ColorGeneratorCode.eventsList15 = function(runtimeScene) {

};gdjs.ColorGeneratorCode.eventsList16 = function(runtimeScene) {

{


{
gdjs.copyArray(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2, gdjs.ColorGeneratorCode.GDWhiteSquareObjects4);

{runtimeScene.getVariables().get("FirstPhaseResult").setNumber(gdjs.randomInRange(1, 6));
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("LoopCounter")).add(1);
}
}}

}


{


gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
{
gdjs.ColorGeneratorCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("FirstPhaseResult")) == 1;
}if (gdjs.ColorGeneratorCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2, gdjs.ColorGeneratorCode.GDWhiteSquareObjects4);

{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("RedValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("GreenValue")).setNumber(255);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("BlueValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("LoopCounter")).add(1);
}
}}

}


{


gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
{
gdjs.ColorGeneratorCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("FirstPhaseResult")) == 2;
}if (gdjs.ColorGeneratorCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2, gdjs.ColorGeneratorCode.GDWhiteSquareObjects4);

{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("RedValue")).setNumber(255);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("GreenValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("BlueValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("LoopCounter")).add(1);
}
}}

}


{


gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
{
gdjs.ColorGeneratorCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("FirstPhaseResult")) == 3;
}if (gdjs.ColorGeneratorCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2, gdjs.ColorGeneratorCode.GDWhiteSquareObjects4);

{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("RedValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("GreenValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("BlueValue")).setNumber(255);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("LoopCounter")).add(1);
}
}}

}


{


gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
{
gdjs.ColorGeneratorCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("FirstPhaseResult")) == 4;
}if (gdjs.ColorGeneratorCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2, gdjs.ColorGeneratorCode.GDWhiteSquareObjects4);

{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("RedValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("GreenValue")).setNumber(255);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("BlueValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("LoopCounter")).add(1);
}
}}

}


{


gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
{
gdjs.ColorGeneratorCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("FirstPhaseResult")) == 5;
}if (gdjs.ColorGeneratorCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2, gdjs.ColorGeneratorCode.GDWhiteSquareObjects4);

{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("RedValue")).setNumber(255);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("GreenValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("BlueValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects4[i].getVariables().get("LoopCounter")).add(1);
}
}}

}


{


gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
{
gdjs.ColorGeneratorCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("FirstPhaseResult")) == 6;
}if (gdjs.ColorGeneratorCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2, gdjs.ColorGeneratorCode.GDWhiteSquareObjects3);

{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].getVariables().get("RedValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].getVariables().get("GreenValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].getVariables().get("BlueValue")).setNumber(255);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].getVariables().get("LoopCounter")).add(1);
}
}}

}


};gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDLoopCounterTextObjects3Objects = Hashtable.newFrom({"LoopCounterText": gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3});gdjs.ColorGeneratorCode.eventsList17 = function(runtimeScene) {

{


gdjs.ColorGeneratorCode.eventsList16(runtimeScene);
}


{



}


{


{
gdjs.copyArray(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2, gdjs.ColorGeneratorCode.GDWhiteSquareObjects3);

gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length = 0;

{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].setColor(gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].getVariables().get("RedValue")))) + ";" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].getVariables().get("GreenValue")))) + ";" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].getVariables().get("BlueValue")))));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDLoopCounterTextObjects3Objects, (( gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length === 0 ) ? 0 :gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[0].getPointX("Center")) - 10, (( gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length === 0 ) ? 0 :gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[0].getPointY("")) + 10, "");
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3[i].setString(gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[0].getVariables()).get("LoopCounter")))));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3[i].setZOrder(100);
}
}}

}


};gdjs.ColorGeneratorCode.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("LoopCounterText"), gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2);

for(gdjs.ColorGeneratorCode.forEachIndex3 = 0;gdjs.ColorGeneratorCode.forEachIndex3 < gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2.length;++gdjs.ColorGeneratorCode.forEachIndex3) {
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length = 0;


gdjs.ColorGeneratorCode.forEachTemporary3 = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2[gdjs.ColorGeneratorCode.forEachIndex3];
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.push(gdjs.ColorGeneratorCode.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3[i].deleteFromScene(runtimeScene);
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("WhiteSquare"), gdjs.ColorGeneratorCode.GDWhiteSquareObjects1);

for(gdjs.ColorGeneratorCode.forEachIndex2 = 0;gdjs.ColorGeneratorCode.forEachIndex2 < gdjs.ColorGeneratorCode.GDWhiteSquareObjects1.length;++gdjs.ColorGeneratorCode.forEachIndex2) {
gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length = 0;


gdjs.ColorGeneratorCode.forEachTemporary2 = gdjs.ColorGeneratorCode.GDWhiteSquareObjects1[gdjs.ColorGeneratorCode.forEachIndex2];
gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.push(gdjs.ColorGeneratorCode.forEachTemporary2);
if (true) {
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("GreenValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("BlueValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("RedValue")).setNumber(0);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("LoopCounter")).setNumber(0);
}
}
{ //Subevents: 
gdjs.ColorGeneratorCode.eventsList17(runtimeScene);} //Subevents end.
}
}

}


};gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDGreyScaleButtonObjects1Objects = Hashtable.newFrom({"GreyScaleButton": gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1});gdjs.ColorGeneratorCode.eventsList19 = function(runtimeScene) {

};gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDLoopCounterTextObjects3Objects = Hashtable.newFrom({"LoopCounterText": gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3});gdjs.ColorGeneratorCode.eventsList20 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2, gdjs.ColorGeneratorCode.GDWhiteSquareObjects3);

gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length = 0;

{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].setColor(gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].getVariables().get("RedValue")))) + ";" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].getVariables().get("GreenValue")))) + ";" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].getVariables().get("BlueValue")))));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDLoopCounterTextObjects3Objects, (( gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length === 0 ) ? 0 :gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[0].getPointX("Center")) - 10, (( gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length === 0 ) ? 0 :gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[0].getPointY("")) + 10, "");
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3[i].setString(gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[0].getVariables()).get("LoopCounter")))));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3[i].setZOrder(100);
}
}}

}


};gdjs.ColorGeneratorCode.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("LoopCounterText"), gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2);

for(gdjs.ColorGeneratorCode.forEachIndex3 = 0;gdjs.ColorGeneratorCode.forEachIndex3 < gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2.length;++gdjs.ColorGeneratorCode.forEachIndex3) {
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length = 0;


gdjs.ColorGeneratorCode.forEachTemporary3 = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2[gdjs.ColorGeneratorCode.forEachIndex3];
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.push(gdjs.ColorGeneratorCode.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3[i].deleteFromScene(runtimeScene);
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("WhiteSquare"), gdjs.ColorGeneratorCode.GDWhiteSquareObjects1);

for(gdjs.ColorGeneratorCode.forEachIndex2 = 0;gdjs.ColorGeneratorCode.forEachIndex2 < gdjs.ColorGeneratorCode.GDWhiteSquareObjects1.length;++gdjs.ColorGeneratorCode.forEachIndex2) {
gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length = 0;


gdjs.ColorGeneratorCode.forEachTemporary2 = gdjs.ColorGeneratorCode.GDWhiteSquareObjects1[gdjs.ColorGeneratorCode.forEachIndex2];
gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.push(gdjs.ColorGeneratorCode.forEachTemporary2);
if (true) {
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("LoopCounter")).setNumber(1);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("GreyValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("RedValue")).setNumber((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("GreyValue"))));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("GreenValue")).setNumber((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("GreyValue"))));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("BlueValue")).setNumber((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("GreyValue"))));
}
}
{ //Subevents: 
gdjs.ColorGeneratorCode.eventsList20(runtimeScene);} //Subevents end.
}
}

}


};gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDPastelsButtonObjects1Objects = Hashtable.newFrom({"PastelsButton": gdjs.ColorGeneratorCode.GDPastelsButtonObjects1});gdjs.ColorGeneratorCode.eventsList22 = function(runtimeScene) {

};gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDLoopCounterTextObjects3Objects = Hashtable.newFrom({"LoopCounterText": gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3});gdjs.ColorGeneratorCode.eventsList23 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2, gdjs.ColorGeneratorCode.GDWhiteSquareObjects3);

gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length = 0;

{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].setColor(gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].getVariables().get("RedValue")))) + ";" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].getVariables().get("GreenValue")))) + ";" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[i].getVariables().get("BlueValue")))));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDLoopCounterTextObjects3Objects, (( gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length === 0 ) ? 0 :gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[0].getPointX("Center")) - 10, (( gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length === 0 ) ? 0 :gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[0].getPointY("")) + 10, "");
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3[i].setString(gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.ColorGeneratorCode.GDWhiteSquareObjects3[0].getVariables()).get("LoopCounter")))));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3[i].setZOrder(100);
}
}}

}


};gdjs.ColorGeneratorCode.eventsList24 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("LoopCounterText"), gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2);

for(gdjs.ColorGeneratorCode.forEachIndex3 = 0;gdjs.ColorGeneratorCode.forEachIndex3 < gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2.length;++gdjs.ColorGeneratorCode.forEachIndex3) {
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length = 0;


gdjs.ColorGeneratorCode.forEachTemporary3 = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2[gdjs.ColorGeneratorCode.forEachIndex3];
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.push(gdjs.ColorGeneratorCode.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3[i].deleteFromScene(runtimeScene);
}
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("WhiteSquare"), gdjs.ColorGeneratorCode.GDWhiteSquareObjects1);

for(gdjs.ColorGeneratorCode.forEachIndex2 = 0;gdjs.ColorGeneratorCode.forEachIndex2 < gdjs.ColorGeneratorCode.GDWhiteSquareObjects1.length;++gdjs.ColorGeneratorCode.forEachIndex2) {
gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length = 0;


gdjs.ColorGeneratorCode.forEachTemporary2 = gdjs.ColorGeneratorCode.GDWhiteSquareObjects1[gdjs.ColorGeneratorCode.forEachIndex2];
gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.push(gdjs.ColorGeneratorCode.forEachTemporary2);
if (true) {
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("LoopCounter")).setNumber(1);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("RedValue")).setNumber((gdjs.randomInRange(0, 255) + 255) / 2);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("GreenValue")).setNumber((gdjs.randomInRange(0, 255) + 255) / 2);
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects2[i].getVariables().get("BlueValue")).setNumber((gdjs.randomInRange(0, 255) + 255) / 2);
}
}
{ //Subevents: 
gdjs.ColorGeneratorCode.eventsList23(runtimeScene);} //Subevents end.
}
}

}


};gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDShowHideNumbersButtonObjects1Objects = Hashtable.newFrom({"ShowHideNumbersButton": gdjs.ColorGeneratorCode.GDShowHideNumbersButtonObjects1});gdjs.ColorGeneratorCode.eventsList25 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("LoopCounterText"), gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2);

gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2.length;i<l;++i) {
    if ( gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2[i].isVisible() ) {
        gdjs.ColorGeneratorCode.condition0IsTrue_0.val = true;
        gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2[k] = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2[i];
        ++k;
    }
}
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2.length = k;}if (gdjs.ColorGeneratorCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("ShowNumbers").setNumber(0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("LoopCounterText"), gdjs.ColorGeneratorCode.GDLoopCounterTextObjects1);

gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects1.length;i<l;++i) {
    if ( !(gdjs.ColorGeneratorCode.GDLoopCounterTextObjects1[i].isVisible()) ) {
        gdjs.ColorGeneratorCode.condition0IsTrue_0.val = true;
        gdjs.ColorGeneratorCode.GDLoopCounterTextObjects1[k] = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects1[i];
        ++k;
    }
}
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects1.length = k;}if (gdjs.ColorGeneratorCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().get("ShowNumbers").setNumber(1);
}}

}


};gdjs.ColorGeneratorCode.eventsList26 = function(runtimeScene) {

{


gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
gdjs.ColorGeneratorCode.condition1IsTrue_0.val = false;
{
gdjs.ColorGeneratorCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.ColorGeneratorCode.condition0IsTrue_0.val ) {
{
{gdjs.ColorGeneratorCode.conditionTrue_1 = gdjs.ColorGeneratorCode.condition1IsTrue_0;
gdjs.ColorGeneratorCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7848412);
}
}}
if (gdjs.ColorGeneratorCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.ColorGeneratorCode.eventsList25(runtimeScene);} //End of subevents
}

}


};gdjs.ColorGeneratorCode.eventsList27 = function(runtimeScene) {

{


gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
{
gdjs.ColorGeneratorCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("ShowNumbers")) == 0;
}if (gdjs.ColorGeneratorCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2, gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3);

{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3[i].hide();
}
}}

}


{


gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
{
gdjs.ColorGeneratorCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("ShowNumbers")) == 1;
}if (gdjs.ColorGeneratorCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2, gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3);

{for(var i = 0, len = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3[i].hide(false);
}
}}

}


};gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDQuestionMarkObjects1Objects = Hashtable.newFrom({"QuestionMark": gdjs.ColorGeneratorCode.GDQuestionMarkObjects1});gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDQuestionMarkObjects1Objects = Hashtable.newFrom({"QuestionMark": gdjs.ColorGeneratorCode.GDQuestionMarkObjects1});gdjs.ColorGeneratorCode.eventsList28 = function(runtimeScene) {

{


gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
{
gdjs.ColorGeneratorCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.ColorGeneratorCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("WhiteSquare"), gdjs.ColorGeneratorCode.GDWhiteSquareObjects1);
{gdjs.evtsExt__CreateMultipleCopiesOfObject__CreateMultipleCopiesOfObject.func(runtimeScene, gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDWhiteSquareObjects1Objects, 10, 20, 0, 0, 0, 0, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("RandomButton"), gdjs.ColorGeneratorCode.GDRandomButtonObjects1);

gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
gdjs.ColorGeneratorCode.condition1IsTrue_0.val = false;
gdjs.ColorGeneratorCode.condition2IsTrue_0.val = false;
{
gdjs.ColorGeneratorCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDRandomButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.ColorGeneratorCode.condition0IsTrue_0.val ) {
{
gdjs.ColorGeneratorCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.ColorGeneratorCode.condition1IsTrue_0.val ) {
{
{gdjs.ColorGeneratorCode.conditionTrue_1 = gdjs.ColorGeneratorCode.condition2IsTrue_0;
gdjs.ColorGeneratorCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7797748);
}
}}
}
if (gdjs.ColorGeneratorCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DarksAndGreysRemovedButton"), gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("DarksRemovedButton"), gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("GreyScaleButton"), gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("GreysRemovedButton"), gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("PastelsButton"), gdjs.ColorGeneratorCode.GDPastelsButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("PureHuesButton"), gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1);
/* Reuse gdjs.ColorGeneratorCode.GDRandomButtonObjects1 */
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDRandomButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDRandomButtonObjects1[i].setAnimationName("Selected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDPastelsButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDPastelsButtonObjects1[i].setAnimationName("NotSelected");
}
}
{ //Subevents
gdjs.ColorGeneratorCode.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("DarksRemovedButton"), gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1);

gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
gdjs.ColorGeneratorCode.condition1IsTrue_0.val = false;
gdjs.ColorGeneratorCode.condition2IsTrue_0.val = false;
{
gdjs.ColorGeneratorCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDDarksRemovedButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.ColorGeneratorCode.condition0IsTrue_0.val ) {
{
gdjs.ColorGeneratorCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.ColorGeneratorCode.condition1IsTrue_0.val ) {
{
{gdjs.ColorGeneratorCode.conditionTrue_1 = gdjs.ColorGeneratorCode.condition2IsTrue_0;
gdjs.ColorGeneratorCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7805308);
}
}}
}
if (gdjs.ColorGeneratorCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DarksAndGreysRemovedButton"), gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1);
/* Reuse gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("GreyScaleButton"), gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("GreysRemovedButton"), gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("PastelsButton"), gdjs.ColorGeneratorCode.GDPastelsButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("PureHuesButton"), gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("RandomButton"), gdjs.ColorGeneratorCode.GDRandomButtonObjects1);
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1[i].setAnimationName("Selected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDRandomButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDRandomButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDPastelsButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDPastelsButtonObjects1[i].setAnimationName("NotSelected");
}
}
{ //Subevents
gdjs.ColorGeneratorCode.eventsList6(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("GreysRemovedButton"), gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1);

gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
gdjs.ColorGeneratorCode.condition1IsTrue_0.val = false;
gdjs.ColorGeneratorCode.condition2IsTrue_0.val = false;
{
gdjs.ColorGeneratorCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDGreysRemovedButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.ColorGeneratorCode.condition0IsTrue_0.val ) {
{
gdjs.ColorGeneratorCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.ColorGeneratorCode.condition1IsTrue_0.val ) {
{
{gdjs.ColorGeneratorCode.conditionTrue_1 = gdjs.ColorGeneratorCode.condition2IsTrue_0;
gdjs.ColorGeneratorCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8215364);
}
}}
}
if (gdjs.ColorGeneratorCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DarksAndGreysRemovedButton"), gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("DarksRemovedButton"), gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("GreyScaleButton"), gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1);
/* Reuse gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("PastelsButton"), gdjs.ColorGeneratorCode.GDPastelsButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("PureHuesButton"), gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("RandomButton"), gdjs.ColorGeneratorCode.GDRandomButtonObjects1);
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1[i].setAnimationName("Selected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDRandomButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDRandomButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDPastelsButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDPastelsButtonObjects1[i].setAnimationName("NotSelected");
}
}
{ //Subevents
gdjs.ColorGeneratorCode.eventsList10(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("DarksAndGreysRemovedButton"), gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1);

gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
gdjs.ColorGeneratorCode.condition1IsTrue_0.val = false;
gdjs.ColorGeneratorCode.condition2IsTrue_0.val = false;
{
gdjs.ColorGeneratorCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDDarksAndGreysRemovedButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.ColorGeneratorCode.condition0IsTrue_0.val ) {
{
gdjs.ColorGeneratorCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.ColorGeneratorCode.condition1IsTrue_0.val ) {
{
{gdjs.ColorGeneratorCode.conditionTrue_1 = gdjs.ColorGeneratorCode.condition2IsTrue_0;
gdjs.ColorGeneratorCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(6016708);
}
}}
}
if (gdjs.ColorGeneratorCode.condition2IsTrue_0.val) {
/* Reuse gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("DarksRemovedButton"), gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("GreyScaleButton"), gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("GreysRemovedButton"), gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("PastelsButton"), gdjs.ColorGeneratorCode.GDPastelsButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("PureHuesButton"), gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("RandomButton"), gdjs.ColorGeneratorCode.GDRandomButtonObjects1);
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDRandomButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDRandomButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1[i].setAnimationName("Selected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDPastelsButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDPastelsButtonObjects1[i].setAnimationName("NotSelected");
}
}
{ //Subevents
gdjs.ColorGeneratorCode.eventsList14(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("PureHuesButton"), gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1);

gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
gdjs.ColorGeneratorCode.condition1IsTrue_0.val = false;
gdjs.ColorGeneratorCode.condition2IsTrue_0.val = false;
{
gdjs.ColorGeneratorCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDPureHuesButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.ColorGeneratorCode.condition0IsTrue_0.val ) {
{
gdjs.ColorGeneratorCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.ColorGeneratorCode.condition1IsTrue_0.val ) {
{
{gdjs.ColorGeneratorCode.conditionTrue_1 = gdjs.ColorGeneratorCode.condition2IsTrue_0;
gdjs.ColorGeneratorCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7836620);
}
}}
}
if (gdjs.ColorGeneratorCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DarksAndGreysRemovedButton"), gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("DarksRemovedButton"), gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("GreyScaleButton"), gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("GreysRemovedButton"), gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("PastelsButton"), gdjs.ColorGeneratorCode.GDPastelsButtonObjects1);
/* Reuse gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("RandomButton"), gdjs.ColorGeneratorCode.GDRandomButtonObjects1);
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDRandomButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDRandomButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1[i].setAnimationName("Selected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDPastelsButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDPastelsButtonObjects1[i].setAnimationName("NotSelected");
}
}
{ //Subevents
gdjs.ColorGeneratorCode.eventsList18(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("GreyScaleButton"), gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1);

gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
gdjs.ColorGeneratorCode.condition1IsTrue_0.val = false;
gdjs.ColorGeneratorCode.condition2IsTrue_0.val = false;
{
gdjs.ColorGeneratorCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDGreyScaleButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.ColorGeneratorCode.condition0IsTrue_0.val ) {
{
gdjs.ColorGeneratorCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.ColorGeneratorCode.condition1IsTrue_0.val ) {
{
{gdjs.ColorGeneratorCode.conditionTrue_1 = gdjs.ColorGeneratorCode.condition2IsTrue_0;
gdjs.ColorGeneratorCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7482388);
}
}}
}
if (gdjs.ColorGeneratorCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DarksAndGreysRemovedButton"), gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("DarksRemovedButton"), gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1);
/* Reuse gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("GreysRemovedButton"), gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("PastelsButton"), gdjs.ColorGeneratorCode.GDPastelsButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("PureHuesButton"), gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("RandomButton"), gdjs.ColorGeneratorCode.GDRandomButtonObjects1);
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDRandomButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDRandomButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1[i].setAnimationName("Selected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDPastelsButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDPastelsButtonObjects1[i].setAnimationName("NotSelected");
}
}
{ //Subevents
gdjs.ColorGeneratorCode.eventsList21(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("PastelsButton"), gdjs.ColorGeneratorCode.GDPastelsButtonObjects1);

gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
gdjs.ColorGeneratorCode.condition1IsTrue_0.val = false;
gdjs.ColorGeneratorCode.condition2IsTrue_0.val = false;
{
gdjs.ColorGeneratorCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDPastelsButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.ColorGeneratorCode.condition0IsTrue_0.val ) {
{
gdjs.ColorGeneratorCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.ColorGeneratorCode.condition1IsTrue_0.val ) {
{
{gdjs.ColorGeneratorCode.conditionTrue_1 = gdjs.ColorGeneratorCode.condition2IsTrue_0;
gdjs.ColorGeneratorCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7758156);
}
}}
}
if (gdjs.ColorGeneratorCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DarksAndGreysRemovedButton"), gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("DarksRemovedButton"), gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("GreyScaleButton"), gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("GreysRemovedButton"), gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1);
/* Reuse gdjs.ColorGeneratorCode.GDPastelsButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("PureHuesButton"), gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("RandomButton"), gdjs.ColorGeneratorCode.GDRandomButtonObjects1);
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDRandomButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDRandomButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1[i].setAnimationName("NotSelected");
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDPastelsButtonObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDPastelsButtonObjects1[i].setAnimationName("Selected");
}
}
{ //Subevents
gdjs.ColorGeneratorCode.eventsList24(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("ShowHideNumbersButton"), gdjs.ColorGeneratorCode.GDShowHideNumbersButtonObjects1);

gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
{
gdjs.ColorGeneratorCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDShowHideNumbersButtonObjects1Objects, runtimeScene, true, false);
}if (gdjs.ColorGeneratorCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.ColorGeneratorCode.eventsList26(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LoopCounterText"), gdjs.ColorGeneratorCode.GDLoopCounterTextObjects1);

for(gdjs.ColorGeneratorCode.forEachIndex2 = 0;gdjs.ColorGeneratorCode.forEachIndex2 < gdjs.ColorGeneratorCode.GDLoopCounterTextObjects1.length;++gdjs.ColorGeneratorCode.forEachIndex2) {
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2.length = 0;


gdjs.ColorGeneratorCode.forEachTemporary2 = gdjs.ColorGeneratorCode.GDLoopCounterTextObjects1[gdjs.ColorGeneratorCode.forEachIndex2];
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2.push(gdjs.ColorGeneratorCode.forEachTemporary2);
if (true) {

{ //Subevents: 
gdjs.ColorGeneratorCode.eventsList27(runtimeScene);} //Subevents end.
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("QuestionMark"), gdjs.ColorGeneratorCode.GDQuestionMarkObjects1);

gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
{
gdjs.ColorGeneratorCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDQuestionMarkObjects1Objects, runtimeScene, true, false);
}if (gdjs.ColorGeneratorCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "Explanation");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("QuestionMark"), gdjs.ColorGeneratorCode.GDQuestionMarkObjects1);

gdjs.ColorGeneratorCode.condition0IsTrue_0.val = false;
{
gdjs.ColorGeneratorCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.ColorGeneratorCode.mapOfGDgdjs_46ColorGeneratorCode_46GDQuestionMarkObjects1Objects, runtimeScene, true, true);
}if (gdjs.ColorGeneratorCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Explanation");
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("WhiteSquare"), gdjs.ColorGeneratorCode.GDWhiteSquareObjects1);
{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects1[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects1[i].getVariables().get("GreyValue")).setNumber(gdjs.randomInRange(0, 255));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects1[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects1[i].getVariables().get("RedValue")).setNumber((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects1[i].getVariables().get("GreyValue"))));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects1[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects1[i].getVariables().get("GreenValue")).setNumber((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects1[i].getVariables().get("GreyValue"))));
}
}{for(var i = 0, len = gdjs.ColorGeneratorCode.GDWhiteSquareObjects1.length ;i < len;++i) {
    gdjs.ColorGeneratorCode.GDWhiteSquareObjects1[i].returnVariable(gdjs.ColorGeneratorCode.GDWhiteSquareObjects1[i].getVariables().get("BlueValue")).setNumber((gdjs.RuntimeObject.getVariableNumber(gdjs.ColorGeneratorCode.GDWhiteSquareObjects1[i].getVariables().get("GreyValue"))));
}
}}

}


{


{
}

}


};

gdjs.ColorGeneratorCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.ColorGeneratorCode.GDWhiteSquareObjects1.length = 0;
gdjs.ColorGeneratorCode.GDWhiteSquareObjects2.length = 0;
gdjs.ColorGeneratorCode.GDWhiteSquareObjects3.length = 0;
gdjs.ColorGeneratorCode.GDWhiteSquareObjects4.length = 0;
gdjs.ColorGeneratorCode.GDWhiteSquareObjects5.length = 0;
gdjs.ColorGeneratorCode.GDShowHideNumbersButtonObjects1.length = 0;
gdjs.ColorGeneratorCode.GDShowHideNumbersButtonObjects2.length = 0;
gdjs.ColorGeneratorCode.GDShowHideNumbersButtonObjects3.length = 0;
gdjs.ColorGeneratorCode.GDShowHideNumbersButtonObjects4.length = 0;
gdjs.ColorGeneratorCode.GDShowHideNumbersButtonObjects5.length = 0;
gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects1.length = 0;
gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects2.length = 0;
gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects3.length = 0;
gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects4.length = 0;
gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedButtonObjects5.length = 0;
gdjs.ColorGeneratorCode.GDPastelsButtonObjects1.length = 0;
gdjs.ColorGeneratorCode.GDPastelsButtonObjects2.length = 0;
gdjs.ColorGeneratorCode.GDPastelsButtonObjects3.length = 0;
gdjs.ColorGeneratorCode.GDPastelsButtonObjects4.length = 0;
gdjs.ColorGeneratorCode.GDPastelsButtonObjects5.length = 0;
gdjs.ColorGeneratorCode.GDPureHuesButtonObjects1.length = 0;
gdjs.ColorGeneratorCode.GDPureHuesButtonObjects2.length = 0;
gdjs.ColorGeneratorCode.GDPureHuesButtonObjects3.length = 0;
gdjs.ColorGeneratorCode.GDPureHuesButtonObjects4.length = 0;
gdjs.ColorGeneratorCode.GDPureHuesButtonObjects5.length = 0;
gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects1.length = 0;
gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects2.length = 0;
gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects3.length = 0;
gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects4.length = 0;
gdjs.ColorGeneratorCode.GDGreysRemovedButtonObjects5.length = 0;
gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects1.length = 0;
gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects2.length = 0;
gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects3.length = 0;
gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects4.length = 0;
gdjs.ColorGeneratorCode.GDDarksRemovedButtonObjects5.length = 0;
gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects1.length = 0;
gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects2.length = 0;
gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects3.length = 0;
gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects4.length = 0;
gdjs.ColorGeneratorCode.GDGreyScaleButtonObjects5.length = 0;
gdjs.ColorGeneratorCode.GDRandomButtonObjects1.length = 0;
gdjs.ColorGeneratorCode.GDRandomButtonObjects2.length = 0;
gdjs.ColorGeneratorCode.GDRandomButtonObjects3.length = 0;
gdjs.ColorGeneratorCode.GDRandomButtonObjects4.length = 0;
gdjs.ColorGeneratorCode.GDRandomButtonObjects5.length = 0;
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects1.length = 0;
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects2.length = 0;
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects3.length = 0;
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects4.length = 0;
gdjs.ColorGeneratorCode.GDLoopCounterTextObjects5.length = 0;
gdjs.ColorGeneratorCode.GDShowHideNumbersTextObjects1.length = 0;
gdjs.ColorGeneratorCode.GDShowHideNumbersTextObjects2.length = 0;
gdjs.ColorGeneratorCode.GDShowHideNumbersTextObjects3.length = 0;
gdjs.ColorGeneratorCode.GDShowHideNumbersTextObjects4.length = 0;
gdjs.ColorGeneratorCode.GDShowHideNumbersTextObjects5.length = 0;
gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedTextObjects1.length = 0;
gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedTextObjects2.length = 0;
gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedTextObjects3.length = 0;
gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedTextObjects4.length = 0;
gdjs.ColorGeneratorCode.GDDarksAndGreysRemovedTextObjects5.length = 0;
gdjs.ColorGeneratorCode.GDGreyScaleTextObjects1.length = 0;
gdjs.ColorGeneratorCode.GDGreyScaleTextObjects2.length = 0;
gdjs.ColorGeneratorCode.GDGreyScaleTextObjects3.length = 0;
gdjs.ColorGeneratorCode.GDGreyScaleTextObjects4.length = 0;
gdjs.ColorGeneratorCode.GDGreyScaleTextObjects5.length = 0;
gdjs.ColorGeneratorCode.GDPureHuesTextObjects1.length = 0;
gdjs.ColorGeneratorCode.GDPureHuesTextObjects2.length = 0;
gdjs.ColorGeneratorCode.GDPureHuesTextObjects3.length = 0;
gdjs.ColorGeneratorCode.GDPureHuesTextObjects4.length = 0;
gdjs.ColorGeneratorCode.GDPureHuesTextObjects5.length = 0;
gdjs.ColorGeneratorCode.GDPastelsTextObjects1.length = 0;
gdjs.ColorGeneratorCode.GDPastelsTextObjects2.length = 0;
gdjs.ColorGeneratorCode.GDPastelsTextObjects3.length = 0;
gdjs.ColorGeneratorCode.GDPastelsTextObjects4.length = 0;
gdjs.ColorGeneratorCode.GDPastelsTextObjects5.length = 0;
gdjs.ColorGeneratorCode.GDGreysRemovedTextObjects1.length = 0;
gdjs.ColorGeneratorCode.GDGreysRemovedTextObjects2.length = 0;
gdjs.ColorGeneratorCode.GDGreysRemovedTextObjects3.length = 0;
gdjs.ColorGeneratorCode.GDGreysRemovedTextObjects4.length = 0;
gdjs.ColorGeneratorCode.GDGreysRemovedTextObjects5.length = 0;
gdjs.ColorGeneratorCode.GDDarksRemovedTextObjects1.length = 0;
gdjs.ColorGeneratorCode.GDDarksRemovedTextObjects2.length = 0;
gdjs.ColorGeneratorCode.GDDarksRemovedTextObjects3.length = 0;
gdjs.ColorGeneratorCode.GDDarksRemovedTextObjects4.length = 0;
gdjs.ColorGeneratorCode.GDDarksRemovedTextObjects5.length = 0;
gdjs.ColorGeneratorCode.GDRandomColorsTextObjects1.length = 0;
gdjs.ColorGeneratorCode.GDRandomColorsTextObjects2.length = 0;
gdjs.ColorGeneratorCode.GDRandomColorsTextObjects3.length = 0;
gdjs.ColorGeneratorCode.GDRandomColorsTextObjects4.length = 0;
gdjs.ColorGeneratorCode.GDRandomColorsTextObjects5.length = 0;
gdjs.ColorGeneratorCode.GDExplanationTextObjects1.length = 0;
gdjs.ColorGeneratorCode.GDExplanationTextObjects2.length = 0;
gdjs.ColorGeneratorCode.GDExplanationTextObjects3.length = 0;
gdjs.ColorGeneratorCode.GDExplanationTextObjects4.length = 0;
gdjs.ColorGeneratorCode.GDExplanationTextObjects5.length = 0;
gdjs.ColorGeneratorCode.GDExplanationBoxObjects1.length = 0;
gdjs.ColorGeneratorCode.GDExplanationBoxObjects2.length = 0;
gdjs.ColorGeneratorCode.GDExplanationBoxObjects3.length = 0;
gdjs.ColorGeneratorCode.GDExplanationBoxObjects4.length = 0;
gdjs.ColorGeneratorCode.GDExplanationBoxObjects5.length = 0;
gdjs.ColorGeneratorCode.GDQuestionMarkObjects1.length = 0;
gdjs.ColorGeneratorCode.GDQuestionMarkObjects2.length = 0;
gdjs.ColorGeneratorCode.GDQuestionMarkObjects3.length = 0;
gdjs.ColorGeneratorCode.GDQuestionMarkObjects4.length = 0;
gdjs.ColorGeneratorCode.GDQuestionMarkObjects5.length = 0;

gdjs.ColorGeneratorCode.eventsList28(runtimeScene);
return;

}

gdjs['ColorGeneratorCode'] = gdjs.ColorGeneratorCode;
